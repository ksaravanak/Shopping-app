namespace ShopKart.Api;

/// <summary>Saves product photos to disk (the uploads folder inside the data directory).</summary>
public sealed class ImageStorage(string root)
{
    public const long MaxFileBytes = 10 * 1024 * 1024;   // 10 MB per photo
    public const int MaxImagesPerProduct = 8;

    public string Root { get; } = root;

    /// <summary>Returns an error message, or null when every file is an acceptable photo.</summary>
    public static async Task<string?> ValidateAsync(IEnumerable<IFormFile> files)
    {
        foreach (var file in files)
        {
            if (file.Length == 0) return $"\"{file.FileName}\" is empty.";
            if (file.Length > MaxFileBytes) return $"\"{file.FileName}\" is larger than 10 MB.";
            if (await DetectExtensionAsync(file) is null)
                return $"\"{file.FileName}\" is not a supported photo. Please use JPG, PNG, WEBP or GIF.";
        }
        return null;
    }

    public async Task<string> SaveAsync(IFormFile file)
    {
        var extension = await DetectExtensionAsync(file)
            ?? throw new InvalidOperationException("Unsupported image format.");
        Directory.CreateDirectory(Root);
        var fileName = $"{Guid.NewGuid():N}{extension}";
        await using var output = File.Create(Path.Combine(Root, fileName));
        await file.CopyToAsync(output);
        return fileName;
    }

    public void Delete(string fileName)
    {
        try
        {
            var path = Path.Combine(Root, Path.GetFileName(fileName));
            if (File.Exists(path)) File.Delete(path);
        }
        catch (IOException)
        {
            // A leftover file is harmless; never fail the request because of it.
        }
    }

    /// <summary>Identifies the format from the file's first bytes rather than trusting its name.</summary>
    private static async Task<string?> DetectExtensionAsync(IFormFile file)
    {
        var header = new byte[12];
        await using var stream = file.OpenReadStream();
        var read = 0;
        while (read < header.Length)
        {
            var count = await stream.ReadAsync(header.AsMemory(read));
            if (count == 0) break;
            read += count;
        }
        if (read >= 3 && header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF) return ".jpg";
        if (read >= 8 && header[0] == 0x89 && header[1] == 0x50 && header[2] == 0x4E && header[3] == 0x47) return ".png";
        if (read >= 4 && header[0] == 'G' && header[1] == 'I' && header[2] == 'F' && header[3] == '8') return ".gif";
        if (read >= 12 && header[0] == 'R' && header[1] == 'I' && header[2] == 'F' && header[3] == 'F' &&
            header[8] == 'W' && header[9] == 'E' && header[10] == 'B' && header[11] == 'P') return ".webp";
        return null;
    }
}
