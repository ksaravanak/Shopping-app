using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace ShopKart.Api;

/// <summary>
/// Sends queued order emails in the background so checkout and admin actions never wait for the mail server.
/// Emails are stored in the database first, so nothing is lost if the app restarts.
/// </summary>
public sealed class NotificationWorker(
    IServiceScopeFactory scopes,
    NotificationSignal signal,
    IOptionsMonitor<EmailOptions> emailOptions,
    IConfiguration configuration,
    ILogger<NotificationWorker> logger) : BackgroundService
{
    private const int MaxAttempts = 4;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ProcessQueueAsync(stoppingToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                logger.LogError(exception, "Email sender failed; will try again shortly.");
            }

            try { await signal.WaitAsync(TimeSpan.FromSeconds(30), stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task ProcessQueueAsync(CancellationToken token)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ShopDbContext>();
        var sender = scope.ServiceProvider.GetRequiredService<EmailSender>();
        var settings = emailOptions.CurrentValue;
        var now = DateTime.UtcNow;

        var queued = await db.OrderNotifications
            .Include(x => x.Order).ThenInclude(x => x!.Items)
            .Where(x => x.Channel == NotificationChannel.Email &&
                        x.Status == NotificationState.Queued &&
                        (x.NextAttemptAt == null || x.NextAttemptAt <= now))
            .OrderBy(x => x.Id)
            .Take(20)
            .ToListAsync(token);

        foreach (var notification in queued)
        {
            await SendAsync(notification, settings, sender, token);
            await db.SaveChangesAsync(token);
        }
    }

    private async Task SendAsync(OrderNotification notification, EmailOptions settings, EmailSender sender, CancellationToken token)
    {
        var order = notification.Order!;
        if (!settings.IsConfigured)
        {
            notification.Status = NotificationState.Failed;
            notification.Detail = "Email is not set up (Email__Enabled, SMTP username and app password).";
            return;
        }

        var to = notification.Event == NotificationEvent.OwnerAlert ? settings.OwnerAddress.Trim() : order.Email;
        if (string.IsNullOrWhiteSpace(to))
        {
            notification.Status = NotificationState.Failed;
            notification.Detail = "No email address to send to.";
            return;
        }

        var storeName = configuration["Store:Name"] ?? "Liyazhini Fashion";
        var publicUrl = configuration["Store:PublicUrl"];
        notification.Attempts++;
        var result = await sender.SendAsync(
            settings, to,
            NotificationTexts.Subject(order, notification.Event, storeName),
            NotificationTexts.Message(order, notification.Event, storeName, publicUrl),
            token);

        if (result.Success)
        {
            notification.Status = NotificationState.Sent;
            notification.SentAt = DateTime.UtcNow;
            notification.Detail = null;
            logger.LogInformation("Email \"{Event}\" sent for order {Order}.", notification.Event, order.OrderNumber);
        }
        else if (result.Retryable && notification.Attempts < MaxAttempts)
        {
            notification.NextAttemptAt = DateTime.UtcNow.AddMinutes(notification.Attempts * 2);
            notification.Detail = result.Error;
            logger.LogWarning("Email \"{Event}\" for order {Order} failed, will retry: {Error}", notification.Event, order.OrderNumber, result.Error);
        }
        else
        {
            notification.Status = NotificationState.Failed;
            notification.Detail = result.Error;
            logger.LogWarning("Email \"{Event}\" for order {Order} failed: {Error}", notification.Event, order.OrderNumber, result.Error);
        }
    }
}
