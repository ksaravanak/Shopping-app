using System.Globalization;

namespace ShopKart.Api;

public static class NotificationEvent
{
    public const string OrderPlaced = "OrderPlaced";
    public const string PaymentConfirmed = "PaymentConfirmed";
    public const string Shipped = "Shipped";
    public const string Delivered = "Delivered";
    public const string OwnerAlert = "OwnerAlert";   // email to the shop owner: new order to verify

    public static string Label(string value) => value switch
    {
        OrderPlaced => "Order placed",
        PaymentConfirmed => "Payment confirmed",
        Shipped => "Shipped",
        Delivered => "Delivered",
        OwnerAlert => "New order alert (to you)",
        _ => value
    };
}

public static class NotificationChannel
{
    public const string Email = "Email";        // sent automatically (free, via your email account)
    public const string WhatsApp = "WhatsApp";  // sent by hand with the "Send on WhatsApp" button (free)
}

public static class NotificationState
{
    public const string Queued = "Queued";          // waiting for the background email sender
    public const string Sent = "Sent";              // email sent
    public const string Failed = "Failed";          // email could not be sent / phone number invalid
    public const string Manual = "Manual";          // WhatsApp message ready — admin sends it by hand
    public const string ManualSent = "ManualSent";  // admin sent the WhatsApp message
}

/// <summary>Wakes the background sender as soon as an email is queued.</summary>
public sealed class NotificationSignal
{
    private readonly SemaphoreSlim _signal = new(0, 1);

    public void Notify()
    {
        try { _signal.Release(); } catch (SemaphoreFullException) { /* already signalled */ }
    }

    public Task WaitAsync(TimeSpan timeout, CancellationToken token) => _signal.WaitAsync(timeout, token);
}

public static class PhoneNumbers
{
    /// <summary>
    /// Converts a typed phone number into the digits-only international form WhatsApp links need
    /// (e.g. "98765 43210" → "919876543210"). Returns null when it does not look like a mobile number.
    /// </summary>
    public static string? ToWhatsApp(string? phone, string defaultCountryCode = "91")
    {
        if (string.IsNullOrWhiteSpace(phone)) return null;
        var trimmed = phone.Trim();
        var digits = new string(trimmed.Where(char.IsAsciiDigit).ToArray());
        var cc = new string((defaultCountryCode ?? "").Where(char.IsAsciiDigit).ToArray());

        if (trimmed.StartsWith('+') || trimmed.StartsWith("00"))
        {
            if (trimmed.StartsWith("00")) digits = digits[2..];
        }
        else if (digits.Length == 11 && digits.StartsWith('0'))
        {
            digits = cc + digits[1..];                       // 098765 43210 → 91 98765 43210
        }
        else if (digits.Length == 10)
        {
            digits = cc + digits;                            // local 10-digit mobile number
        }

        return digits.Length is >= 10 and <= 15 && digits[0] != '0' ? digits : null;
    }
}

/// <summary>Message wording shared by the WhatsApp links and the emails.</summary>
public static class NotificationTexts
{
    private static readonly CultureInfo India = CultureInfo.GetCultureInfo("en-IN");

    public static string Money(decimal amount) =>
        "₹" + amount.ToString(amount % 1 == 0 ? "#,##0" : "#,##0.00", India);

    public static string FirstName(string name)
    {
        var first = (name ?? "").Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
        return string.IsNullOrEmpty(first) ? "there" : first;
    }

    /// <summary>Message text. Words wrapped in *asterisks* are bold (WhatsApp style; converted for email).</summary>
    public static string Message(Order order, string notificationEvent, string storeName, string? publicUrl)
    {
        var name = FirstName(order.CustomerName);
        var items = string.Join("\n", order.Items.Select(x => $"• {x.Quantity} × {x.ProductName}"));
        var track = string.IsNullOrWhiteSpace(publicUrl)
            ? ""
            : $"\n\nTrack your order: {publicUrl.TrimEnd('/')} (My orders → {order.Email})";

        var body = notificationEvent switch
        {
            NotificationEvent.OrderPlaced =>
                $"Hi {name}, thank you for shopping with {storeName}! 🛍️\n\n" +
                $"We have received your order *{order.OrderNumber}* and your UPI payment details for *{Money(order.Total)}*.\n\n" +
                $"{items}\n\nWe will confirm your order as soon as the payment is verified.",
            NotificationEvent.PaymentConfirmed =>
                $"Hi {name}, your payment of *{Money(order.Total)}* for order *{order.OrderNumber}* has been received ✅\n\n" +
                $"Your order is confirmed and we are getting it ready.\n\n{items}",
            NotificationEvent.Shipped =>
                $"Hi {name}, good news! Your {storeName} order *{order.OrderNumber}* has been shipped 🚚\n\n" +
                $"It is on its way to:\n{order.Address}",
            NotificationEvent.Delivered =>
                $"Hi {name}, your order *{order.OrderNumber}* has been delivered 🎉\n\n" +
                $"Thank you for shopping with {storeName}. We hope you love it!",
            NotificationEvent.OwnerAlert =>
                $"New order *{order.OrderNumber}* is waiting for payment verification.\n\n" +
                $"Amount: *{Money(order.Total)}*\nUPI transaction ID (UTR): *{order.PaymentReference}*\n\n" +
                $"Customer: {order.CustomerName}\nPhone: {order.Phone}\nEmail: {order.Email}\nAddress:\n{order.Address}\n\n{items}\n\n" +
                "Check your bank / UPI app for this UTR and amount, then open Store admin → Orders and click \"Payment received\".",
            _ => $"Hi {name}, an update on your order *{order.OrderNumber}*: {order.Status}."
        };
        return notificationEvent == NotificationEvent.OwnerAlert ? body : body + track;
    }

    public static string Subject(Order order, string notificationEvent, string storeName) => notificationEvent switch
    {
        NotificationEvent.OrderPlaced => $"We received your order {order.OrderNumber} – {storeName}",
        NotificationEvent.PaymentConfirmed => $"Payment received – order {order.OrderNumber} is confirmed",
        NotificationEvent.Shipped => $"Your order {order.OrderNumber} has been shipped",
        NotificationEvent.Delivered => $"Your order {order.OrderNumber} has been delivered",
        NotificationEvent.OwnerAlert => $"New order {order.OrderNumber} – verify payment {Money(order.Total)} (UTR {order.PaymentReference})",
        _ => $"Update on your order {order.OrderNumber}"
    };

    /// <summary>Click-to-chat link that opens WhatsApp with the message already typed (free, sent by hand).</summary>
    public static string? WhatsAppLink(Order order, string notificationEvent, string countryCode, string storeName, string? publicUrl)
    {
        var to = PhoneNumbers.ToWhatsApp(order.Phone, countryCode);
        return to is null
            ? null
            : $"https://wa.me/{to}?text={Uri.EscapeDataString(Message(order, notificationEvent, storeName, publicUrl))}";
    }
}
