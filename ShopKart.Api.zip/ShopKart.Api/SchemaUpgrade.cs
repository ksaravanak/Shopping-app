using Microsoft.EntityFrameworkCore;

namespace ShopKart.Api;

/// <summary>
/// Creates the database on first run and adds columns introduced by later versions
/// to an existing database, so no data is lost when the app is updated.
/// </summary>
public static class SchemaUpgrade
{
    private static readonly (string Table, string Column, string Definition)[] AddedColumns =
    [
        ("Orders", "PaymentMethod", "TEXT NOT NULL DEFAULT 'COD'"),       // orders placed before UPI were cash on delivery
        ("Orders", "PaymentStatus", "TEXT NOT NULL DEFAULT 'Pending'"),
        ("Orders", "PaymentReference", "TEXT NULL"),
        ("Orders", "PaidAt", "TEXT NULL"),
        ("OrderNotifications", "Channel", "TEXT NOT NULL DEFAULT 'WhatsApp'"),  // rows from the earlier WhatsApp-only version
    ];

    // Data fixes that are safe to run on every start.
    private static readonly string[] DataFixes =
    [
        // WhatsApp messages are now always sent by hand; release any left queued for the removed automatic sender.
        """UPDATE "OrderNotifications" SET "Status" = 'Manual', "Detail" = NULL WHERE "Channel" = 'WhatsApp' AND ("Status" = 'Queued' OR ("Status" = 'Failed' AND "Detail" NOT LIKE '%not a valid mobile number%'))""",
    ];

    // Same layout EF Core creates for a new database; "IF NOT EXISTS" makes these no-ops there.
    private static readonly string[] AddedTables =
    [
        """
        CREATE TABLE IF NOT EXISTS "OrderNotifications" (
            "Id" INTEGER NOT NULL CONSTRAINT "PK_OrderNotifications" PRIMARY KEY AUTOINCREMENT,
            "OrderId" INTEGER NOT NULL,
            "Channel" TEXT NOT NULL,
            "Event" TEXT NOT NULL,
            "Status" TEXT NOT NULL,
            "Detail" TEXT NULL,
            "ExternalId" TEXT NULL,
            "Attempts" INTEGER NOT NULL,
            "NextAttemptAt" TEXT NULL,
            "CreatedAt" TEXT NOT NULL,
            "SentAt" TEXT NULL,
            CONSTRAINT "FK_OrderNotifications_Orders_OrderId" FOREIGN KEY ("OrderId") REFERENCES "Orders" ("Id") ON DELETE CASCADE
        )
        """,
        """CREATE INDEX IF NOT EXISTS "IX_OrderNotifications_OrderId" ON "OrderNotifications" ("OrderId")""",
        """CREATE INDEX IF NOT EXISTS "IX_OrderNotifications_Status" ON "OrderNotifications" ("Status")""",
    ];

    public static async Task RunAsync(ShopDbContext db)
    {
        await db.Database.EnsureCreatedAsync();

        var connection = db.Database.GetDbConnection();
        await connection.OpenAsync();
        try
        {
            foreach (var sql in AddedTables)
            {
                await using var command = connection.CreateCommand();
                command.CommandText = sql;
                await command.ExecuteNonQueryAsync();
            }

            foreach (var table in AddedColumns.Select(x => x.Table).Distinct())
            {
                var existing = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                await using (var command = connection.CreateCommand())
                {
                    command.CommandText = $"SELECT name FROM pragma_table_info('{table}')";
                    await using var reader = await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync()) existing.Add(reader.GetString(0));
                }

                foreach (var (_, column, definition) in AddedColumns.Where(x => x.Table == table && !existing.Contains(x.Column)))
                {
                    await using var command = connection.CreateCommand();
                    command.CommandText = $"ALTER TABLE \"{table}\" ADD COLUMN \"{column}\" {definition}";
                    await command.ExecuteNonQueryAsync();
                }
            }

            await using (var command = connection.CreateCommand())
            {
                command.CommandText = "CREATE INDEX IF NOT EXISTS \"IX_Orders_PaymentReference\" ON \"Orders\" (\"PaymentReference\")";
                await command.ExecuteNonQueryAsync();
            }

            foreach (var sql in DataFixes)
            {
                await using var command = connection.CreateCommand();
                command.CommandText = sql;
                await command.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await connection.CloseAsync();
        }
    }
}
