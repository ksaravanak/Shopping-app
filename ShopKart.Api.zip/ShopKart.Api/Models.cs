namespace ShopKart.Api;

// ---------- Database entities ----------

public sealed class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "";
    public decimal Price { get; set; }
    public decimal OriginalPrice { get; set; }
    public int Stock { get; set; }
    public bool IsFeatured { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public List<ProductImage> Images { get; set; } = [];
}

public sealed class ProductImage
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    public string FileName { get; set; } = "";
    public int SortOrder { get; set; }
}

public sealed class Order
{
    public int Id { get; set; }
    public string OrderNumber { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Address { get; set; } = "";
    public List<OrderItem> Items { get; set; } = [];
    public decimal Subtotal { get; set; }
    public decimal DeliveryFee { get; set; }
    public decimal Total { get; set; }
    public string Status { get; set; } = OrderState.AwaitingPayment;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Payment
    public string PaymentMethod { get; set; } = PaymentState.MethodUpi;   // "UPI" (older orders: "COD")
    public string PaymentStatus { get; set; } = PaymentState.Pending;
    public string? PaymentReference { get; set; }                          // UPI transaction ID (UTR) from the customer
    public DateTime? PaidAt { get; set; }

    public List<OrderNotification> Notifications { get; set; } = [];
}

/// <summary>An order update for the customer (email or WhatsApp). Emails wait here until the background sender sends them.</summary>
public sealed class OrderNotification
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public string Channel { get; set; } = NotificationChannel.Email;
    public string Event { get; set; } = "";
    public string Status { get; set; } = NotificationState.Queued;
    public string? Detail { get; set; }
    public string? ExternalId { get; set; }
    public int Attempts { get; set; }
    public DateTime? NextAttemptAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? SentAt { get; set; }
}

public static class OrderState
{
    public const string AwaitingPayment = "Awaiting payment";
    public const string Confirmed = "Confirmed";
    public const string Cancelled = "Cancelled";
    public static readonly string[] AdminStatuses = [Confirmed, "Packed", "Shipped", "Delivered", Cancelled];
}

public static class PaymentState
{
    public const string MethodUpi = "UPI";
    public const string Pending = "Pending";       // waiting for the customer to pay
    public const string Submitted = "Submitted";   // customer entered a UTR; admin must check the bank app
    public const string Paid = "Paid";             // admin verified the money arrived
    public const string Failed = "Failed";         // admin could not find the payment
    public const string Expired = "Expired";       // not paid within the time limit
}

public sealed class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    // Plain value (no foreign key) so past orders survive when a product is deleted.
    public int ProductId { get; set; }
    public string ProductName { get; set; } = "";
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
}

// ---------- API contracts ----------

public sealed record ImageDto(int Id, string Url);

public sealed record ProductDto(
    int Id,
    string Name,
    string Description,
    string Category,
    decimal Price,
    decimal OriginalPrice,
    int Stock,
    bool IsFeatured,
    string ImageUrl,
    IReadOnlyList<ImageDto> Images);

public sealed record NotificationDto(int Id, string Channel, string Event, string Label, string Status, string? Detail, DateTime CreatedAt, string? ManualLink);

public sealed record OrderItemDto(int ProductId, string ProductName, decimal UnitPrice, int Quantity);

public sealed record OrderDto(
    int Id,
    string OrderNumber,
    string CustomerName,
    string Email,
    string Phone,
    string Address,
    IReadOnlyList<OrderItemDto> Items,
    decimal Subtotal,
    decimal DeliveryFee,
    decimal Total,
    string Status,
    DateTime CreatedAt,
    string PaymentMethod,
    string PaymentStatus,
    string? PaymentReference,
    DateTime? PaidAt,
    DateTime? PaymentDueAt,
    string? WhatsAppNumber = null,
    IReadOnlyList<NotificationDto>? Notifications = null);

public sealed record ProductInput(
    string Name,
    string Description,
    string Category,
    decimal Price,
    decimal OriginalPrice,
    int Stock,
    bool IsFeatured = false);

public sealed record LoginRequest(string Username, string Password);
public sealed record StockRequest(int Quantity);
public sealed record StatusRequest(string Status);
public sealed record PaymentSubmission(string Email, string Reference);
public sealed record PaymentDecision(bool Approve);
public sealed record CheckoutItem(int ProductId, int Quantity);
public sealed record CheckoutRequest(
    string CustomerName,
    string Email,
    string Phone,
    string Address,
    List<CheckoutItem> Items);

public static class Mapping
{
    public static string ImageUrl(string fileName) => $"/uploads/{fileName}";

    public static ProductDto ToDto(this Product product)
    {
        var images = product.Images
            .OrderBy(x => x.SortOrder).ThenBy(x => x.Id)
            .Select(x => new ImageDto(x.Id, ImageUrl(x.FileName)))
            .ToList();
        return new ProductDto(
            product.Id, product.Name, product.Description, product.Category,
            product.Price, product.OriginalPrice, product.Stock, product.IsFeatured,
            images.FirstOrDefault()?.Url ?? "", images);
    }

    /// <summary>Admin view: includes the WhatsApp number, message log and manual-send links.</summary>
    public static OrderDto ToAdminDto(this Order order, int paymentTimeoutMinutes, string countryCode, string storeName, string? publicUrl) =>
        order.ToDto(paymentTimeoutMinutes) with
        {
            WhatsAppNumber = PhoneNumbers.ToWhatsApp(order.Phone, countryCode),
            Notifications = order.Notifications.OrderBy(x => x.Id).Select(x => new NotificationDto(
                x.Id, x.Channel, x.Event, NotificationEvent.Label(x.Event), x.Status, x.Detail,
                DateTime.SpecifyKind(x.CreatedAt, DateTimeKind.Utc),
                x.Channel == NotificationChannel.WhatsApp
                    ? NotificationTexts.WhatsAppLink(order, x.Event, countryCode, storeName, publicUrl)
                    : null)).ToList()
        };

    public static OrderDto ToDto(this Order order, int paymentTimeoutMinutes = 30)
    {
        var createdAt = DateTime.SpecifyKind(order.CreatedAt, DateTimeKind.Utc);
        DateTime? dueAt = order.PaymentMethod == PaymentState.MethodUpi && order.PaymentStatus == PaymentState.Pending
            ? createdAt.AddMinutes(paymentTimeoutMinutes)
            : null;
        return new OrderDto(
            order.Id, order.OrderNumber, order.CustomerName, order.Email, order.Phone, order.Address,
            order.Items.Select(x => new OrderItemDto(x.ProductId, x.ProductName, x.UnitPrice, x.Quantity)).ToList(),
            order.Subtotal, order.DeliveryFee, order.Total, order.Status, createdAt,
            order.PaymentMethod, order.PaymentStatus, order.PaymentReference,
            order.PaidAt is { } paid ? DateTime.SpecifyKind(paid, DateTimeKind.Utc) : null,
            dueAt);
    }
}
