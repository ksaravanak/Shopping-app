const CART_KEY = "liyazhini-cart";
const MAX_PHOTOS = 8;
const MAX_PHOTO_BYTES = 10 * 1024 * 1024;

const state = {
  products: [],
  category: "All",
  search: "",
  cart: readCart(),
  store: { name: "Liyazhini Fashion", deliveryFee: 49, freeDeliveryAbove: 499, paymentTimeoutMinutes: 30, upiId: null, upiPayeeName: "Liyazhini Fashion" },
  payment: null,          // { orderNumber, email, total, dueAt } for the payment dialog
  lookupEmail: "",
  lookupOrders: [],
  emailOn: false,
  admin: false,
  newPhotos: [],
  deleteArmed: false
};

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const money = value => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fallbackImage = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='750'%3E%3Crect width='100%25' height='100%25' fill='%23f3ece6'/%3E%3Ctext x='50%25' y='52%25' text-anchor='middle' font-size='90' fill='%23c9a9b4'%3E✿%3C/text%3E%3C/svg%3E";

function readCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY) || "[]"); } catch { return []; }
}

async function api(path, options = {}) {
  const isForm = options.body instanceof FormData;
  const response = await fetch(path, {
    credentials: "same-origin",
    ...options,
    headers: isForm ? (options.headers || {}) : { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = response.status === 204 ? null : await response.json().catch(() => null);
  if (response.status === 401 && path.startsWith("/api/admin/") && path !== "/api/admin/login") {
    setAdmin(false);
    throw new Error("Your admin session has ended. Please sign in again.");
  }
  if (response.status === 413) throw new Error("Those photos are too large to upload together. Try fewer at a time.");
  if (response.status === 429) throw new Error("Too many attempts. Please wait a minute and try again.");
  if (!response.ok) throw new Error(data?.message || "Something went wrong. Please try again.");
  return data;
}

// ---------- Catalogue ----------

async function loadStore() {
  try { state.store = { ...state.store, ...(await api("/api/store")) }; } catch { /* defaults are fine */ }
  $("#hero-free-delivery").textContent = `${money(state.store.freeDeliveryAbove)}+`;
  $("#free-delivery-note").textContent = `Free delivery on orders above ${money(state.store.freeDeliveryAbove)}`;
}

async function loadProducts() {
  state.products = await api("/api/products");
  renderCategories();
  renderProducts();
  renderCart();
}

function filteredProducts() {
  const query = state.search.toLowerCase();
  return state.products.filter(product =>
    (state.category === "All" || product.category === state.category) &&
    (!query || [product.name, product.description, product.category].some(x => x.toLowerCase().includes(query)))
  );
}

function categories() {
  return [...new Set(state.products.map(x => x.category))].sort((a, b) => a.localeCompare(b));
}

function renderCategories() {
  const list = ["All", ...categories()];
  if (!list.includes(state.category)) state.category = "All";
  $("#categories").innerHTML = list.map(category =>
    `<button class="category-chip ${category === state.category ? "active" : ""}" data-category="${escapeHtml(category)}">${escapeHtml(category)}</button>`
  ).join("");
  $("#category-options").innerHTML = categories().map(x => `<option value="${escapeHtml(x)}">`).join("");
}

function discountOf(product) {
  return product.originalPrice > product.price ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;
}

function renderProducts() {
  const products = filteredProducts();
  const storeEmpty = state.products.length === 0;
  $("#result-count").textContent = `${products.length} product${products.length === 1 ? "" : "s"}`;
  $("#empty-products").classList.toggle("hidden", products.length > 0);
  $("#empty-title").textContent = storeEmpty ? "New collection coming soon" : "No products found";
  $("#empty-text").textContent = storeEmpty ? "We're adding fresh styles. Please check back shortly." : "Try another search or category.";
  $("#product-grid").innerHTML = products.map(product => {
    const discount = discountOf(product);
    return `<article class="product-card">
      <button class="product-image" data-view="${product.id}" aria-label="View ${escapeHtml(product.name)}">
        <img src="${escapeHtml(product.imageUrl || fallbackImage)}" alt="${escapeHtml(product.name)}" loading="lazy" onerror="this.src='${fallbackImage}'">
        ${discount ? `<span class="discount">${discount}% OFF</span>` : ""}
        ${product.images.length > 1 ? `<span class="photo-count">${product.images.length} photos</span>` : ""}
        <span class="stock-badge">${product.stock > 0 ? (product.stock <= 3 ? `Only ${product.stock} left` : "In stock") : "Sold out"}</span>
      </button>
      <div class="product-info">
        <span class="product-category">${escapeHtml(product.category)}</span>
        <h3><button class="link-button" data-view="${product.id}">${escapeHtml(product.name)}</button></h3>
        <p>${escapeHtml(product.description)}</p>
        <div class="price-line"><span class="price">${money(product.price)}</span>${discount ? `<span class="mrp">${money(product.originalPrice)}</span>` : ""}</div>
        <button class="add-button" data-add="${product.id}" ${product.stock < 1 ? "disabled" : ""}>${product.stock > 0 ? "Add to bag" : "Out of stock"}</button>
      </div>
    </article>`;
  }).join("");
}

function openProduct(id) {
  const product = state.products.find(x => x.id === id);
  if (!product) return;
  const photos = product.images.length ? product.images.map(x => x.url) : [fallbackImage];
  const discount = discountOf(product);
  $("#product-detail").innerHTML = `
    <div class="gallery">
      <img class="gallery-main" id="gallery-main" src="${escapeHtml(photos[0])}" alt="${escapeHtml(product.name)}" onerror="this.src='${fallbackImage}'">
      ${photos.length > 1 ? `<div class="gallery-thumbs">${photos.map((url, i) =>
        `<button class="${i === 0 ? "active" : ""}" data-photo="${escapeHtml(url)}"><img src="${escapeHtml(url)}" alt="Photo ${i + 1}"></button>`).join("")}</div>` : ""}
    </div>
    <div class="detail-info">
      <span class="product-category">${escapeHtml(product.category)}</span>
      <h2>${escapeHtml(product.name)}</h2>
      <div class="price-line"><span class="price">${money(product.price)}</span>${discount ? `<span class="mrp">${money(product.originalPrice)}</span><span class="save">${discount}% off</span>` : ""}</div>
      <p class="detail-description">${escapeHtml(product.description) || "—"}</p>
      <p class="detail-stock">${product.stock > 0 ? (product.stock <= 3 ? `Hurry, only ${product.stock} left` : "In stock") : "Currently sold out"}</p>
      <button class="primary-button full" data-add="${product.id}" ${product.stock < 1 ? "disabled" : ""}>${product.stock > 0 ? "Add to bag" : "Out of stock"}</button>
    </div>`;
  $("#product-modal").showModal();
}

// ---------- Cart ----------

function persistCart() {
  try { localStorage.setItem(CART_KEY, JSON.stringify(state.cart)); } catch { /* private mode */ }
  renderCart();
}

function addToCart(productId) {
  const product = state.products.find(x => x.id === productId);
  if (!product || product.stock < 1) return;
  const existing = state.cart.find(x => x.productId === productId);
  if (existing && existing.quantity >= product.stock) return showToast("No more stock is available.");
  if (existing) existing.quantity++;
  else state.cart.push({ productId, quantity: 1 });
  persistCart();
  showToast(`${product.name} added to bag`);
}

function updateQuantity(productId, delta) {
  const item = state.cart.find(x => x.productId === productId);
  const product = state.products.find(x => x.id === productId);
  if (!item || !product) return;
  const next = item.quantity + delta;
  if (next > product.stock) return showToast("Quantity exceeds available stock.");
  if (next < 1) state.cart = state.cart.filter(x => x.productId !== productId);
  else item.quantity = next;
  persistCart();
}

function cartTotals() {
  const subtotal = state.cart.reduce((sum, item) => {
    const product = state.products.find(x => x.id === item.productId);
    return sum + (product?.price || 0) * item.quantity;
  }, 0);
  const delivery = subtotal === 0 || subtotal >= state.store.freeDeliveryAbove ? 0 : state.store.deliveryFee;
  return { subtotal, delivery, total: subtotal + delivery };
}

function renderCart() {
  state.cart = state.cart.filter(item => state.products.some(product => product.id === item.productId));
  const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  $("#cart-count").textContent = count;
  $("#cart-empty").classList.toggle("hidden", count > 0);
  $("#cart-summary").classList.toggle("hidden", count === 0);
  $("#cart-items").innerHTML = state.cart.map(item => {
    const product = state.products.find(x => x.id === item.productId);
    return `<div class="cart-item">
      <img src="${escapeHtml(product.imageUrl || fallbackImage)}" alt="">
      <div><h4>${escapeHtml(product.name)}</h4><p>${money(product.price)}</p>
        <div class="quantity"><button data-qty="${product.id}" data-delta="-1" aria-label="Decrease">−</button><b>${item.quantity}</b><button data-qty="${product.id}" data-delta="1" aria-label="Increase">+</button></div>
      </div>
      <button class="remove" data-remove="${product.id}">Remove</button>
    </div>`;
  }).join("");
  const totals = cartTotals();
  $("#cart-subtotal").textContent = money(totals.subtotal);
  $("#cart-delivery").textContent = totals.delivery ? money(totals.delivery) : "FREE";
  $("#cart-total").textContent = $("#checkout-total").textContent = money(totals.total);
}

function openCart() {
  $("#scrim").classList.remove("hidden");
  $("#cart-drawer").classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeCart() {
  $("#scrim").classList.add("hidden");
  $("#cart-drawer").classList.remove("open");
  document.body.style.overflow = "";
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2800);
}

async function checkout(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const button = event.submitter;
  button.disabled = true;
  button.textContent = "Creating order…";
  try {
    const form = new FormData(formElement);
    const order = await api("/api/orders", {
      method: "POST",
      body: JSON.stringify({
        customerName: form.get("customerName"),
        email: form.get("email"),
        phone: form.get("phone"),
        address: form.get("address"),
        items: state.cart
      })
    });
    state.cart = [];
    persistCart();
    await loadProducts();
    $("#checkout-modal").close();
    formElement.reset();
    openPayment(order);
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = "Continue to UPI payment →";
  }
}

// ---------- Customer orders ----------

function paymentLabel(order) {
  if (order.paymentMethod !== "UPI") return "Cash on delivery";
  return {
    Pending: "UPI · awaiting payment",
    Submitted: "UPI · paid, verifying",
    Paid: "UPI · payment received",
    Failed: "UPI · payment not received",
    Expired: "UPI · not paid in time"
  }[order.paymentStatus] || `UPI · ${order.paymentStatus}`;
}

function orderCard(order, admin = false) {
  const items = order.items.map(item => `${item.quantity} × ${escapeHtml(item.productName)}`).join(", ");
  const cancelled = order.status === "Cancelled";
  const isUpi = order.paymentMethod === "UPI";
  const paid = !isUpi || order.paymentStatus === "Paid";
  const statuses = ["Confirmed", "Packed", "Shipped", "Delivered", "Cancelled"];
  const shownStatus = order.status === "Awaiting payment" && order.paymentStatus === "Submitted" ? "Verifying payment" : order.status;
  const statusBadge = `<span class="status ${cancelled ? "cancelled" : ""} ${order.status === "Awaiting payment" ? "waiting" : ""}">${escapeHtml(shownStatus)}</span>`;
  const statusControl = admin && !cancelled && paid
    ? `<select data-order-status="${order.id}">${statuses.map(status => `<option ${status === order.status ? "selected" : ""}>${status}</option>`).join("")}</select>`
    : statusBadge;
  const phone = admin && order.whatsAppNumber
    ? `<a class="wa-chat" href="https://wa.me/${escapeHtml(order.whatsAppNumber)}" target="_blank" rel="noopener" title="Chat on WhatsApp">${escapeHtml(order.phone)}</a>`
    : escapeHtml(order.phone);
  const contact = admin ? `<p>${phone} · ${escapeHtml(order.email)}<br>${escapeHtml(order.address)}</p>` : "";
  const utr = order.paymentReference ? ` · UTR <b class="utr">${escapeHtml(order.paymentReference)}</b>` : "";
  let actions = "";
  if (admin && isUpi && !cancelled && !paid) {
    actions = `<div class="pay-actions">
      <button class="save-button" data-payment="${order.id}" data-approve="true">Payment received</button>
      <button class="danger-button small" data-payment="${order.id}" data-approve="false">Not received — cancel</button></div>`;
  } else if (!admin && isUpi && !cancelled && order.paymentStatus === "Pending") {
    actions = `<div class="pay-actions"><button class="primary-button" data-pay-order="${escapeHtml(order.orderNumber)}">Pay now with UPI</button></div>`;
  }
  return `<article class="order-card ${admin && order.paymentStatus === "Submitted" && !cancelled ? "needs-check" : ""}"><div class="order-top"><h4>${escapeHtml(order.orderNumber)}</h4>${statusControl}</div>
    <p>${new Date(order.createdAt).toLocaleString("en-IN")} · ${escapeHtml(order.customerName)}</p>${contact}
    <p>${items}</p><div class="order-bottom"><b>${money(order.total)}</b><span class="pay-label">${paymentLabel(order)}${utr}</span></div>${actions}${admin ? updatesSection(order) : ""}</article>`;
}

function updatesSection(order) {
  const notes = order.notifications || [];
  if (!notes.length) return "";
  const stateText = n => ({
    Queued: `<span class="wa-state wait">Sending…</span>`,
    Sent: `<span class="wa-state ok">✓ Sent</span>`,
    ManualSent: `<span class="wa-state ok">✓ Sent by you</span>`,
    Manual: `<span class="wa-state todo">Ready to send</span>`,
    Failed: `<span class="wa-state bad" title="${escapeHtml(n.detail || "")}">✗ Failed</span>`
  }[n.status] || escapeHtml(n.status));
  const row = n => {
    const isWa = n.channel === "WhatsApp";
    const send = isWa && n.manualLink && n.status === "Manual"
      ? `<a class="wa-button" href="${escapeHtml(n.manualLink)}" target="_blank" rel="noopener" data-wa-manual="${n.id}">Send on WhatsApp</a>` : "";
    const resend = isWa && n.manualLink && n.status === "ManualSent"
      ? `<a class="text-button small" href="${escapeHtml(n.manualLink)}" target="_blank" rel="noopener">Open again</a>` : "";
    const retry = !isWa && n.status === "Failed" && state.emailOn ? `<button class="text-button small" data-wa-retry="${n.id}">Retry</button>` : "";
    const detail = n.status === "Failed" && n.detail ? `<small class="wa-detail">${escapeHtml(n.detail)}</small>` : "";
    return `<div class="wa-row"><span class="ch-tag ${isWa ? "wa" : "mail"}">${isWa ? "WhatsApp" : "Email"}</span><span class="wa-event">${escapeHtml(n.label)}</span>${stateText(n)}<span class="wa-actions">${retry}${resend}${send}</span>${detail}</div>`;
  };
  return `<div class="wa-box"><span class="wa-title">Customer updates</span>${notes.map(row).join("")}</div>`;
}

// ---------- UPI payment ----------

function upiLink(order) {
  // Only the payee name and note need encoding; the UPI ID is validated on the server.
  return `upi://pay?pa=${state.store.upiId}&pn=${encodeURIComponent(state.store.upiPayeeName)}` +
    `&am=${Number(order.total).toFixed(2)}&cu=INR&tn=${encodeURIComponent(`Order ${order.orderNumber}`)}`;
}

function openPayment(order) {
  if (!state.store.upiId) return showToast("Online payment is not set up yet. Please try again later.");
  state.payment = { orderNumber: order.orderNumber, email: order.email, total: order.total, dueAt: order.paymentDueAt ? new Date(order.paymentDueAt) : null };
  const link = upiLink(order);
  $("#pay-amount").textContent = money(order.total);
  $("#pay-order").textContent = order.orderNumber;
  $("#pay-upi-id").textContent = state.store.upiId;
  $("#pay-app-link").href = link;
  try {
    const qr = qrcode(0, "M");
    qr.addData(link);
    qr.make();
    $("#pay-qr").innerHTML = qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
  } catch {
    $("#pay-qr").innerHTML = "<p>Use the UPI ID below to pay.</p>";
  }
  $("#pay-step").classList.remove("hidden");
  $("#pay-done").classList.add("hidden");
  $("#payment-form").reset();
  updatePayTimer();
  clearInterval(openPayment.timer);
  openPayment.timer = setInterval(updatePayTimer, 1000);
  if (!$("#payment-modal").open) $("#payment-modal").showModal();
}

function updatePayTimer() {
  const due = state.payment?.dueAt;
  if (!due) { $("#pay-timer").textContent = ""; return; }
  const left = Math.max(0, Math.floor((due - Date.now()) / 1000));
  $("#pay-timer").textContent = left > 0
    ? `Pay within ${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`
    : "Payment time is over — if you already paid, submit the transaction ID now";
  $("#pay-timer").classList.toggle("late", left === 0);
}

async function submitPayment(event) {
  event.preventDefault();
  const button = event.submitter;
  const reference = new FormData(event.currentTarget).get("reference").trim();
  button.disabled = true;
  try {
    const order = await api(`/api/orders/${encodeURIComponent(state.payment.orderNumber)}/payment`, {
      method: "POST",
      body: JSON.stringify({ email: state.payment.email, reference })
    });
    clearInterval(openPayment.timer);
    $("#done-order").textContent = order.orderNumber;
    $("#pay-step").classList.add("hidden");
    $("#pay-done").classList.remove("hidden");
    if (state.lookupEmail) refreshLookup();
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
  }
}

async function copyUpiId() {
  try {
    await navigator.clipboard.writeText(state.store.upiId);
    showToast("UPI ID copied");
  } catch {
    showToast(state.store.upiId);
  }
}

// ---------- Customer orders ----------

async function refreshLookup() {
  state.lookupOrders = await api(`/api/orders?email=${encodeURIComponent(state.lookupEmail)}`);
  $("#customer-order-list").innerHTML = state.lookupOrders.length ? state.lookupOrders.map(x => orderCard(x)).join("") : "<p>No orders found for this email.</p>";
}

async function findOrders(event) {
  event.preventDefault();
  try {
    state.lookupEmail = new FormData(event.currentTarget).get("email").trim();
    await refreshLookup();
  } catch (error) { showToast(error.message); }
}

// ---------- Admin ----------

function setAdmin(signedIn) {
  state.admin = signedIn;
  $("#login-form").classList.toggle("hidden", signedIn);
  $("#admin-area").classList.toggle("hidden", !signedIn);
  $("#logout-button").classList.toggle("hidden", !signedIn);
}

async function openAdmin() {
  try {
    const me = await api("/api/admin/me");
    setAdmin(me.authenticated);
  } catch { setAdmin(false); }
  if (state.admin) { renderInventory(); switchTab("inventory"); }
  $("#admin-modal").showModal();
  if (!state.admin) $("#login-form [name=password]").focus();
}

async function login(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    await api("/api/admin/login", { method: "POST", body: JSON.stringify({ username: form.get("username"), password: form.get("password") }) });
    event.currentTarget.reset();
    setAdmin(true);
    renderInventory();
    switchTab("inventory");
  } catch (error) { showToast(error.message); }
}

async function logout() {
  try { await api("/api/admin/logout", { method: "POST" }); } catch { /* ignore */ }
  setAdmin(false);
  showToast("Signed out");
}

function switchTab(name) {
  $$(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.tab === name || (name === "edit" && tab.dataset.tab === "inventory")));
  $$(".tab-panel").forEach(panel => panel.classList.add("hidden"));
  $(`#${name}-panel`).classList.remove("hidden");
  if (name === "orders") loadAdminOrders();
}

function renderInventory() {
  $("#inventory-list").innerHTML = state.products.length ? state.products.map(product => `<form class="inventory-row" data-quick-form="${product.id}">
    <img src="${escapeHtml(product.imageUrl || fallbackImage)}" alt="">
    <div><b>${escapeHtml(product.name)}</b><p>${escapeHtml(product.category)} · ${product.images.length} photo${product.images.length === 1 ? "" : "s"}</p></div>
    <label class="cell cell-price"><span>Price ₹</span><input type="number" name="price" min="1" step=".01" value="${product.price}" required></label>
    <label class="cell cell-mrp"><span>MRP ₹</span><input type="number" name="originalPrice" min="0" step=".01" value="${product.originalPrice}"></label>
    <label class="cell cell-stock"><span>Stock</span><input type="number" name="stock" min="0" value="${product.stock}" required></label>
    <div class="row-actions"><button class="save-button" type="submit">Save</button><button class="text-button" type="button" data-edit="${product.id}">Edit</button></div>
  </form>`).join("") : `<p class="muted-note">No products yet. Use <b>Add product</b> to upload your first item.</p>`;
}

function productPayload(product, overrides = {}) {
  return {
    name: product.name, description: product.description, category: product.category,
    price: product.price, originalPrice: product.originalPrice, stock: product.stock,
    isFeatured: product.isFeatured, ...overrides
  };
}

async function quickSave(event) {
  const form = event.target.closest("[data-quick-form]");
  if (!form) return;
  event.preventDefault();
  const id = Number(form.dataset.quickForm);
  const product = state.products.find(x => x.id === id);
  const data = new FormData(form);
  try {
    await api(`/api/admin/products/${id}`, {
      method: "PUT",
      body: JSON.stringify(productPayload(product, {
        price: Number(data.get("price")), originalPrice: Number(data.get("originalPrice") || 0), stock: Number(data.get("stock"))
      }))
    });
    await loadProducts();
    renderInventory();
    showToast("Price and stock saved");
  } catch (error) { showToast(error.message); }
}

function checkPhotos(files, existing = 0) {
  if (files.length + existing > MAX_PHOTOS) return `You can have up to ${MAX_PHOTOS} photos per product.`;
  const big = files.find(f => f.size > MAX_PHOTO_BYTES);
  if (big) return `"${big.name}" is larger than 10 MB.`;
  const wrong = files.find(f => !/^image\/(jpeg|png|webp|gif)$/.test(f.type));
  if (wrong) return `"${wrong.name}" is not a JPG, PNG, WEBP or GIF photo.`;
  return null;
}

function renderNewPhotos() {
  $("#new-photo-preview").innerHTML = state.newPhotos.map((file, i) => `<figure class="photo-tile">
    <img src="${URL.createObjectURL(file)}" alt="">${i === 0 ? `<span class="cover-tag">Cover</span>` : ""}
    <button type="button" class="tile-remove" data-new-remove="${i}" aria-label="Remove photo">×</button></figure>`).join("");
}

function pickNewPhotos(event) {
  const files = [...event.target.files];
  event.target.value = "";
  const error = checkPhotos(files, state.newPhotos.length);
  if (error) return showToast(error);
  state.newPhotos.push(...files);
  renderNewPhotos();
}

async function addProduct(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const button = event.submitter;
  const form = new FormData(formElement);
  form.delete("photos");
  state.newPhotos.forEach(file => form.append("photos", file, file.name));
  if (!form.get("isFeatured")) form.set("isFeatured", "false");
  button.disabled = true;
  button.textContent = state.newPhotos.length ? "Uploading photos…" : "Saving…";
  try {
    await api("/api/admin/products", { method: "POST", body: form });
    formElement.reset();
    state.newPhotos = [];
    renderNewPhotos();
    await loadProducts();
    renderInventory();
    switchTab("inventory");
    showToast("Product added to collection");
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = "Add to collection";
  }
}

function openEditor(id) {
  const product = state.products.find(x => x.id === id);
  if (!product) return;
  const form = $("#edit-form");
  form.elements.id.value = product.id;
  form.elements.name.value = product.name;
  form.elements.category.value = product.category;
  form.elements.price.value = product.price;
  form.elements.originalPrice.value = product.originalPrice;
  form.elements.stock.value = product.stock;
  form.elements.description.value = product.description;
  form.elements.isFeatured.checked = product.isFeatured;
  disarmDelete();
  renderEditPhotos(product);
  switchTab("edit");
}

function renderEditPhotos(product) {
  $("#edit-photos").innerHTML = product.images.length ? product.images.map((image, i) => `<figure class="photo-tile">
    <img src="${escapeHtml(image.url)}" alt="">
    ${i === 0 ? `<span class="cover-tag">Cover</span>` : `<button type="button" class="tile-cover" data-cover="${image.id}">Make cover</button>`}
    <button type="button" class="tile-remove" data-image-remove="${image.id}" aria-label="Delete photo">×</button></figure>`).join("")
    : `<p class="muted-note">No photos yet.</p>`;
}

function currentEditId() { return Number($("#edit-form").elements.id.value); }

async function refreshEditor(updated) {
  await loadProducts();
  renderInventory();
  renderEditPhotos(state.products.find(x => x.id === updated.id) || updated);
}

async function saveEdit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const id = currentEditId();
  try {
    await api(`/api/admin/products/${id}`, {
      method: "PUT",
      body: JSON.stringify({
        name: form.elements.name.value, category: form.elements.category.value, description: form.elements.description.value,
        price: Number(form.elements.price.value), originalPrice: Number(form.elements.originalPrice.value || 0),
        stock: Number(form.elements.stock.value), isFeatured: form.elements.isFeatured.checked
      })
    });
    await loadProducts();
    renderInventory();
    switchTab("inventory");
    showToast("Product updated");
  } catch (error) { showToast(error.message); }
}

async function uploadEditPhotos(event) {
  const files = [...event.target.files];
  event.target.value = "";
  const product = state.products.find(x => x.id === currentEditId());
  const error = checkPhotos(files, product?.images.length || 0);
  if (error) return showToast(error);
  if (!files.length) return;
  const form = new FormData();
  files.forEach(file => form.append("photos", file, file.name));
  showToast("Uploading photos…");
  try {
    const updated = await api(`/api/admin/products/${currentEditId()}/images`, { method: "POST", body: form });
    await refreshEditor(updated);
    showToast("Photos added");
  } catch (error) { showToast(error.message); }
}

async function photoAction(event) {
  const remove = event.target.closest("[data-image-remove]");
  const cover = event.target.closest("[data-cover]");
  if (!remove && !cover) return;
  const id = currentEditId();
  try {
    const updated = remove
      ? await api(`/api/admin/products/${id}/images/${remove.dataset.imageRemove}`, { method: "DELETE" })
      : await api(`/api/admin/products/${id}/images/${cover.dataset.cover}/cover`, { method: "PUT" });
    await refreshEditor(updated);
    showToast(remove ? "Photo deleted" : "Cover photo updated");
  } catch (error) { showToast(error.message); }
}

function disarmDelete() {
  state.deleteArmed = false;
  $("#delete-product").textContent = "Delete product";
  $("#delete-product").classList.remove("armed");
}

async function deleteProduct() {
  if (!state.deleteArmed) {
    state.deleteArmed = true;
    $("#delete-product").textContent = "Click again to delete permanently";
    $("#delete-product").classList.add("armed");
    clearTimeout(deleteProduct.timer);
    deleteProduct.timer = setTimeout(disarmDelete, 4000);
    return;
  }
  try {
    await api(`/api/admin/products/${currentEditId()}`, { method: "DELETE" });
    disarmDelete();
    await loadProducts();
    renderInventory();
    switchTab("inventory");
    showToast("Product deleted");
  } catch (error) { showToast(error.message); }
}

async function loadAdminOrders() {
  try {
    const [orders, status] = await Promise.all([api("/api/admin/orders"), api("/api/admin/notifications/status").catch(() => ({ email: false }))]);
    state.emailOn = status.email;
    const toCheck = orders.filter(x => x.paymentStatus === "Submitted" && x.status !== "Cancelled").length;
    $('.tab[data-tab="orders"]').textContent = toCheck ? `Orders (${toCheck} to verify)` : "Orders";
    $("#order-list").innerHTML = orders.length
      ? (toCheck ? `<p class="verify-note">Check your bank / UPI app for each transaction ID (UTR) and amount before marking a payment as received.</p>` : "") + orders.map(x => orderCard(x, true)).join("")
      : "<p class='muted-note'>No orders yet.</p>";
  } catch (error) { showToast(error.message); }
}

// ---------- Events ----------

document.addEventListener("click", event => {
  const add = event.target.closest("[data-add]");
  const view = event.target.closest("[data-view]");
  const category = event.target.closest("[data-category]");
  const qty = event.target.closest("[data-qty]");
  const remove = event.target.closest("[data-remove]");
  const photo = event.target.closest("[data-photo]");
  const edit = event.target.closest("[data-edit]");
  const newRemove = event.target.closest("[data-new-remove]");
  const tab = event.target.closest("[data-tab]");
  if (add) addToCart(Number(add.dataset.add));
  if (view) openProduct(Number(view.dataset.view));
  if (category) { state.category = category.dataset.category; renderCategories(); renderProducts(); }
  if (qty) updateQuantity(Number(qty.dataset.qty), Number(qty.dataset.delta));
  if (remove) { state.cart = state.cart.filter(x => x.productId !== Number(remove.dataset.remove)); persistCart(); }
  if (photo) {
    $("#gallery-main").src = photo.dataset.photo;
    $$(".gallery-thumbs button").forEach(b => b.classList.toggle("active", b === photo));
  }
  if (edit) openEditor(Number(edit.dataset.edit));
  if (newRemove) { state.newPhotos.splice(Number(newRemove.dataset.newRemove), 1); renderNewPhotos(); }
  if (tab) switchTab(tab.dataset.tab);
});

$("#search-form").addEventListener("submit", event => event.preventDefault());
$("#search-input").addEventListener("input", event => { state.search = event.target.value.trim(); renderProducts(); });
$("#cart-button").addEventListener("click", openCart);
$("#scrim").addEventListener("click", closeCart);
$("[data-close]").addEventListener("click", closeCart);
$("[data-shop-now]").addEventListener("click", () => $("#products-section").scrollIntoView({ behavior: "smooth" }));
$("#checkout-button").addEventListener("click", () => {
  if (!state.store.upiId) return showToast("Online payment is not set up yet, so orders can't be placed right now.");
  closeCart();
  $("#checkout-modal").showModal();
});
$("#payment-form").addEventListener("submit", submitPayment);
$("#copy-upi").addEventListener("click", copyUpiId);
$("#payment-modal").addEventListener("close", () => clearInterval(openPayment.timer));
$("#customer-order-list").addEventListener("click", event => {
  const pay = event.target.closest("[data-pay-order]");
  if (!pay) return;
  const order = state.lookupOrders.find(x => x.orderNumber === pay.dataset.payOrder);
  if (order) { $("#orders-modal").close(); openPayment(order); }
});
$("#order-list").addEventListener("click", async event => {
  const manual = event.target.closest("[data-wa-manual]");
  const retry = event.target.closest("[data-wa-retry]");
  if (manual) {
    // The link opens WhatsApp in a new tab; record that it was sent by hand.
    api(`/api/admin/notifications/${manual.dataset.waManual}/manual-sent`, { method: "PUT" })
      .then(() => setTimeout(loadAdminOrders, 800)).catch(error => showToast(error.message));
    return;
  }
  if (retry) {
    try {
      await api(`/api/admin/notifications/${retry.dataset.waRetry}/retry`, { method: "POST" });
      showToast("Sending again…");
      setTimeout(loadAdminOrders, 2500);
    } catch (error) { showToast(error.message); }
    return;
  }
  const button = event.target.closest("[data-payment]");
  if (!button) return;
  const approve = button.dataset.approve === "true";
  button.disabled = true;
  try {
    await api(`/api/admin/orders/${button.dataset.payment}/payment`, { method: "PUT", body: JSON.stringify({ approve }) });
    showToast(approve ? "Payment received — order confirmed. Send the WhatsApp update below." : "Order cancelled and stock restored");
    await loadProducts();
    renderInventory();
    loadAdminOrders();
  } catch (error) { showToast(error.message); button.disabled = false; }
});
$("#checkout-form").addEventListener("submit", checkout);
$("#admin-button").addEventListener("click", openAdmin);
$("#footer-admin").addEventListener("click", openAdmin);
$("#login-form").addEventListener("submit", login);
$("#logout-button").addEventListener("click", logout);
$("#orders-button").addEventListener("click", () => $("#orders-modal").showModal());
$("#product-form").addEventListener("submit", addProduct);
$("#new-photos").addEventListener("change", pickNewPhotos);
$("#edit-form").addEventListener("submit", saveEdit);
$("#edit-photo-input").addEventListener("change", uploadEditPhotos);
$("#edit-photos").addEventListener("click", photoAction);
$("#delete-product").addEventListener("click", deleteProduct);
$("#inventory-list").addEventListener("submit", quickSave);
$("#orders-search").addEventListener("submit", findOrders);
$("#order-list").addEventListener("change", async event => {
  if (!event.target.dataset.orderStatus) return;
  try {
    await api(`/api/admin/orders/${event.target.dataset.orderStatus}/status`, { method: "PUT", body: JSON.stringify({ status: event.target.value }) });
    showToast(["Shipped", "Delivered"].includes(event.target.value) ? "Status updated — send the WhatsApp update below" : "Order status updated");
    await loadProducts();
    loadAdminOrders();
  } catch (error) { showToast(error.message); loadAdminOrders(); }
});
$$("[data-dialog-close]").forEach(button => button.addEventListener("click", () => button.closest("dialog").close()));
$("#product-modal").addEventListener("click", event => { if (event.target.id === "product-modal") event.target.close(); });
$("#year").textContent = new Date().getFullYear();

loadStore().then(loadProducts).catch(error => showToast(error.message));
