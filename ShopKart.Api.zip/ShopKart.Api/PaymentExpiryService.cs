namespace ShopKart.Api;

/// <summary>Every few minutes, cancels UPI orders that were never paid and returns their items to stock.</summary>
public sealed class PaymentExpiryService(IServiceScopeFactory scopes, ILogger<PaymentExpiryService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(2));
        do
        {
            try
            {
                using var scope = scopes.CreateScope();
                var cancelled = await scope.ServiceProvider.GetRequiredService<ShopStore>().CancelExpiredOrdersAsync();
                if (cancelled > 0) logger.LogInformation("Cancelled {Count} unpaid order(s) and restored their stock.", cancelled);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                logger.LogError(exception, "Could not cancel expired unpaid orders.");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }
}
