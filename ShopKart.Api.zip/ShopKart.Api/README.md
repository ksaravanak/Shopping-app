<<<<<<< HEAD
# Liyazhini Fashion

Online store for Liyazhini Fashion, built with ASP.NET Core 8 and a SQLite database.

- Product catalogue with search, categories and a photo gallery for each product
- Store admin (password-protected): add products, **upload photos**, set **price / MRP / stock**, choose the cover photo, delete products
- Shopping bag and checkout with **UPI payment** (QR code + "Open UPI app" button), stock checks, customer order lookup
- Order management: verify UPI payments, then Confirmed → Packed → Shipped → Delivered (Cancelled puts the items back into stock)
- **Free customer updates** (order placed, payment confirmed, shipped, delivered): automatic **emails** through your Gmail account,
  plus ready-made **WhatsApp** messages you send with one tap — and an email alert to you for every new order

## Where data is stored

Everything lives in one **data folder**:

| What | Path inside the data folder |
|---|---|
| SQLite database | `liyazhini.db` |
| Uploaded product photos | `uploads/` |
| Admin sign-in keys | `keys/` |

The folder is `App_Data/` next to the app by default (`/app/data` in Docker). Change it with the `Storage__DataPath` setting.
**Back up this folder** to back up the whole shop.

## Run on your PC (Visual Studio or command line)

Requires the [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0).

```powershell
dotnet run --urls http://localhost:5100
```

Open <http://localhost:5100>, then click **Store admin** (top bar, or at the bottom of the page on phones).
In Development the admin login is **admin / admin123** (set in `appsettings.Development.json`).
Put your UPI ID in `Payment:UpiId` in `appsettings.Development.json` (or set `Payment__UpiId`) — checkout is disabled until it is set.

## Run with Docker

1. Copy `.env.example` to `.env`, set a strong `ADMIN_PASSWORD` and your `UPI_ID`.
2. Start it:

   ```bash
   docker compose up -d --build
   ```

3. Open <http://localhost:8080>.

The database and photos are kept in the `liyazhini-data` Docker volume, so they survive `docker compose down` and image rebuilds.
To update the app later: `git pull` (or copy the new code), then `docker compose up -d --build` again.

Back up the volume:

```bash
docker run --rm -v shopkartapi_liyazhini-data:/data -v "$PWD":/backup alpine tar czf /backup/liyazhini-backup.tgz -C /data .
```

(Run `docker volume ls` to see the exact volume name; it is prefixed with the folder name.)

Without Compose:

```bash
docker build -t liyazhini-fashion .
docker run -d -p 8080:8080 -e Admin__Password=YourStrongPassword -e Payment__UpiId=yourname@okaxis -v liyazhini-data:/app/data --name liyazhini-fashion liyazhini-fashion
```

## Hosting somewhere else

Any host that runs a Docker container with a **persistent disk/volume** works (a VPS with Docker, Azure App Service for Containers, Railway, Render, Fly.io, etc.):

- Mount the persistent disk at `/app/data` (or point `Storage__DataPath` at it).
- Set `Admin__Password`, `Payment__UpiId` (and optionally `Admin__Username`) as environment variables.
- Serve it over **HTTPS** (most hosts do this for you; on a VPS put Caddy or Nginx in front).
- With Nginx, allow photo uploads: `client_max_body_size 100m;`

SQLite is a single file, so run **one** instance of the app. Hosts whose disk is wiped on every deploy (no persistent volume) will lose products and photos.

## Settings

All settings can be given in `appsettings.json` or as environment variables (use `__` for nesting):

| Setting | Env variable | Default |
|---|---|---|
| Admin username | `Admin__Username` | `admin` |
| Admin password | `Admin__Password` | *(empty — admin disabled until set)* |
| Data folder | `Storage__DataPath` | `App_Data` |
| Delivery fee (₹) | `Store__DeliveryFee` | `49` |
| Free delivery above (₹) | `Store__FreeDeliveryAbove` | `499` |
| UPI ID customers pay to | `Payment__UpiId` | *(empty — checkout disabled until set)* |
| Name shown in the UPI app | `Payment__PayeeName` | `Liyazhini Fashion` |
| Minutes to pay before an order is cancelled | `Store__PaymentTimeoutMinutes` | `30` |
| Shop web address (shown in messages) | `Store__PublicUrl` | *(empty)* |
| Country code added to 10-digit phone numbers | `Store__PhoneCountryCode` | `91` |
| Send order emails | `Email__Enabled` | `false` |
| Email server / port | `Email__SmtpHost` / `Email__SmtpPort` | `smtp.gmail.com` / `587` |
| Email login | `Email__Username` | *(empty)* |
| Email app password | `Email__Password` | *(empty)* |
| Sender name | `Email__FromName` | `Liyazhini Fashion` |
| Sender address (if different from login) | `Email__FromAddress` | *(the login address)* |
| Your email for new-order alerts | `Email__OwnerAddress` | *(empty — no alerts)* |
| Custom DB connection string | `ConnectionStrings__Shop` | *(uses the data folder)* |

## UPI payments — how they work

Payments go **directly to your UPI ID**, with no payment gateway and no fees. The flip side is that the app cannot see
your bank account, so you confirm each payment yourself:

1. The customer fills in delivery details → the order is created as **Awaiting payment** and the items are held in stock.
2. The customer scans the QR code (or taps **Open UPI app** on a phone), pays the exact amount, then enters the
   **UPI transaction ID (UTR / UPI Ref No.)** shown in their UPI app.
3. In **Store admin → Orders**, orders waiting for you are highlighted. Check your bank / UPI business app for that UTR and
   amount, then click **Payment received** (order becomes *Confirmed*) or **Not received — cancel** (stock is restored).
4. Orders not paid within `PaymentTimeoutMinutes` (default 30) are cancelled automatically and their stock is released.
   Orders where the customer already entered a UTR are never auto-cancelled — they wait for you.

Customers who closed the payment screen can finish paying from **My orders → Pay now with UPI**.

Tips:

- Use a **business / merchant UPI ID** (e.g. from Google Pay for Business, PhonePe Business, Paytm for Business or your bank).
  Some UPI apps limit or block payments started from a QR/link to a *personal* UPI ID.
- Always match **both the UTR and the amount** in your bank app before clicking *Payment received*. The app rejects a UTR that
  was already used on another order, but it cannot check that the money arrived.
- Cancelling an order that was already paid does not refund it — send the refund from your UPI app.
- Orders placed before UPI was added are shown as *Cash on delivery* and work as before.

## Order notifications (free)

| Moment | Customer email (automatic) | WhatsApp (one tap) | You |
|---|---|---|---|
| Customer submits UPI payment (order placed + amount sent) | ✓ | ✓ | ✓ email alert: "verify payment" |
| You click **Payment received** | ✓ | ✓ | |
| You set the status to **Shipped** | ✓ | ✓ | |
| You set the status to **Delivered** | ✓ | ✓ | |

Each order in **Store admin → Orders** has a *Customer updates* list showing what was sent.

### Emails — automatic and free (Gmail)

Emails are sent from your own Gmail account over SMTP, with no paid service involved. Gmail limits how many emails an account
can send per day (a few hundred for a normal Gmail account), which is plenty for a small shop.

1. Use (or create) a Gmail account for the shop, e.g. a new address just for the shop.
2. Turn on **2-Step Verification**: Google Account → Security.
3. Create an **App password**: Google Account → Security → 2-Step Verification → *App passwords*
   (or search "App passwords" in your Google Account). Name it "Liyazhini Fashion" and copy the 16-letter password.
   Your normal Gmail password will not work here.
4. Set (in `.env` for Docker):

   ```env
   EMAIL_ENABLED=true
   EMAIL_USERNAME=your-shop@gmail.com
   EMAIL_APP_PASSWORD=abcd efgh ijkl mnop
   OWNER_EMAIL=you@example.com      # optional: alert for every new order to verify
   PUBLIC_URL=https://your-shop-address   # optional: adds a "Track your order" link
   ```

   Outside Docker, use `Email__Enabled`, `Email__Username`, `Email__Password`, `Email__OwnerAddress`
   (environment variables or `appsettings.json`).
5. Restart the app.

Other providers work too: set `Email__SmtpHost` / `Email__SmtpPort` (use a port with STARTTLS, usually 587; port 465 is not supported).
Emails are queued and sent in the background, so checkout never waits. Temporary errors are retried automatically.
If an email fails, the order shows why, with a **Retry** button.

### WhatsApp — one tap, free

For each update, **Send on WhatsApp** opens WhatsApp (phone app or WhatsApp Web) with the customer's number and the full
message already typed. You just press Send, and it is marked *Sent by you*. No WhatsApp Business API or paid service is used.
Tip: open Store admin on the phone that has your shop's WhatsApp, or keep WhatsApp Web signed in on your computer.

## Photos

JPG, PNG, WEBP or GIF, up to 10 MB each and 8 per product. The first photo is the cover shown in the catalogue;
use **Make cover** in the product editor to change it. iPhone HEIC photos must be exported as JPG first
(iPhone: Settings → Camera → Formats → *Most Compatible*).

## Notes

- The database tables are created automatically on first start (`EnsureCreated`). If you later change the entity
  classes, switch to EF Core migrations (`dotnet ef migrations add Initial`) before adding new columns.
- Existing databases are upgraded automatically on start-up (new payment columns and the notifications table are added; no data is lost).
- There are no customer accounts; customers look up orders by email.
- The QR code is drawn in the browser by [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) (MIT), stored in `wwwroot/lib/` — no external service is called.
=======
# Shopping-app
shopping app
>>>>>>> origin/main
