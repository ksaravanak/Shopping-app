using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;

namespace ShopKart.Api;

/// <summary>SMTP settings. Works free with a Gmail / Google Workspace account and an app password.</summary>
public sealed class EmailOptions
{
    public bool Enabled { get; set; }
    public string SmtpHost { get; set; } = "smtp.gmail.com";
    public int SmtpPort { get; set; } = 587;
    public bool UseSsl { get; set; } = true;          // STARTTLS on port 587
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";        // for Gmail: a 16-letter app password, not your normal password
    public string FromAddress { get; set; } = "";      // defaults to Username
    public string FromName { get; set; } = "Liyazhini Fashion";
    public string OwnerAddress { get; set; } = "";     // where "new order to verify" alerts go (empty = no alerts)

    public string From => string.IsNullOrWhiteSpace(FromAddress) ? Username.Trim() : FromAddress.Trim();

    public bool IsConfigured =>
        Enabled && !string.IsNullOrWhiteSpace(SmtpHost) && !string.IsNullOrWhiteSpace(From);

    public bool SendsOwnerAlerts => IsConfigured && !string.IsNullOrWhiteSpace(OwnerAddress);
}

public sealed record EmailResult(bool Success, bool Retryable, string? Error);

public sealed class EmailSender
{
    public async Task<EmailResult> SendAsync(EmailOptions options, string to, string subject, string text, CancellationToken token)
    {
        try
        {
            using var message = new MailMessage
            {
                From = new MailAddress(options.From, options.FromName),
                Subject = subject,
                SubjectEncoding = Encoding.UTF8,
                Body = PlainText(text),
                BodyEncoding = Encoding.UTF8,
                IsBodyHtml = false
            };
            message.To.Add(new MailAddress(to));
            message.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(Html(text, options.FromName), Encoding.UTF8, "text/html"));

            using var client = new SmtpClient(options.SmtpHost.Trim(), options.SmtpPort)
            {
                EnableSsl = options.UseSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Timeout = 30_000
            };
            if (!string.IsNullOrWhiteSpace(options.Username))
                client.Credentials = new NetworkCredential(options.Username.Trim(), options.Password.Replace(" ", ""));

            // SendMailAsync ignores SmtpClient.Timeout, so enforce a time limit ourselves.
            using var timeLimit = CancellationTokenSource.CreateLinkedTokenSource(token);
            timeLimit.CancelAfter(TimeSpan.FromSeconds(60));
            await client.SendMailAsync(message, timeLimit.Token);
            return new EmailResult(true, false, null);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            return new EmailResult(false, true, "The email server did not respond in time.");
        }
        catch (FormatException)
        {
            return new EmailResult(false, false, $"\"{to}\" is not a valid email address.");
        }
        catch (SmtpFailedRecipientException exception)
        {
            return new EmailResult(false, false, exception.Message);
        }
        catch (SmtpException exception) when (exception.StatusCode is SmtpStatusCode.MustIssueStartTlsFirst
                                              or SmtpStatusCode.ClientNotPermitted)
        {
            return new EmailResult(false, false, "Email login failed — check the email username and app password. " + exception.Message);
        }
        catch (SmtpException exception)
        {
            var authProblem = exception.Message.Contains("Authentication", StringComparison.OrdinalIgnoreCase) ||
                              exception.Message.Contains("5.7.", StringComparison.Ordinal);
            var detail = exception.InnerException is null ? exception.Message : $"{exception.Message} {exception.InnerException.Message}";
            return new EmailResult(false, !authProblem,
                authProblem ? "Email login failed — check the email username and app password. " + detail : detail);
        }
        catch (Exception exception) when (exception is IOException or System.Net.Sockets.SocketException or InvalidOperationException)
        {
            return new EmailResult(false, true, "Could not reach the email server: " + exception.Message);
        }
    }

    private static string PlainText(string text) => text.Replace("*", "");

    private static string Html(string text, string storeName)
    {
        var encoded = WebUtility.HtmlEncode(text);
        encoded = Regex.Replace(encoded, @"\*([^*\n]+)\*", "<b>$1</b>");
        encoded = Regex.Replace(encoded, @"(https?://[^\s<]+)", "<a href=\"$1\">$1</a>");
        encoded = encoded.Replace("\n", "<br>");
        return $"""
            <!doctype html><html><body style="margin:0;background:#faf6f1;font-family:Arial,Helvetica,sans-serif;color:#24161c">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
            <table role="presentation" width="100%" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden">
            <tr><td style="background:#6b1d3f;color:#f2c46d;padding:18px 24px;font:bold 20px Georgia,serif">{WebUtility.HtmlEncode(storeName)}</td></tr>
            <tr><td style="padding:24px;font-size:15px;line-height:1.6">{encoded}</td></tr>
            </table></td></tr></table></body></html>
            """;
    }
}
