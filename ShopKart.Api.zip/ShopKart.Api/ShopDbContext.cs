using Microsoft.EntityFrameworkCore;

namespace ShopKart.Api;

public sealed class ShopDbContext(DbContextOptions<ShopDbContext> options) : DbContext(options)
{
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductImage> ProductImages => Set<ProductImage>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<OrderNotification> OrderNotifications => Set<OrderNotification>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Product>().HasIndex(x => x.Category);
        modelBuilder.Entity<Order>().HasIndex(x => x.Email);
        modelBuilder.Entity<Order>().HasIndex(x => x.OrderNumber).IsUnique();
        modelBuilder.Entity<Order>().HasIndex(x => x.PaymentReference);
        modelBuilder.Entity<OrderNotification>().HasIndex(x => x.Status);
    }
}
