using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace ShopKart.Api;

public sealed class StoreException(string message) : Exception(message);

public sealed class ShopStore(
    ShopDbContext db,
    ImageStorage images,
    IConfiguration configuration,
    NotificationSignal notificationSignal,
    IOptionsMonitor<EmailOptions> email)
{
    // SQLite allows one writer at a time; this also keeps stock checks and stock changes atomic.
    private static readonly SemaphoreSlim WriteGate = new(1, 1);


    public decimal DeliveryFee => configuration.GetValue("Store:DeliveryFee", 49m);
    public decimal FreeDeliveryAbove => configuration.GetValue("Store:FreeDeliveryAbove", 499m);
    public int PaymentTimeoutMinutes => Math.Max(5, configuration.GetValue("Store:PaymentTimeoutMinutes", 30));
    public string StoreName => configuration["Store:Name"] ?? "Liyazhini Fashion";
    public string? PublicUrl => configuration["Store:PublicUrl"];
    public string PhoneCountryCode => configuration["Store:PhoneCountryCode"] is { Length: > 0 } cc ? cc : "91";

    // ---------- Products ----------

    public async Task<List<ProductDto>> GetProductsAsync(string? search, string? category)
    {
        var products = await db.Products.Include(x => x.Images).ToListAsync();
        IEnumerable<Product> query = products;
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(x =>
                x.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.Category.Contains(search, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(category) && category != "All")
            query = query.Where(x => x.Category.Equals(category, StringComparison.OrdinalIgnoreCase));
        return query
            .OrderByDescending(x => x.IsFeatured)
            .ThenByDescending(x => x.CreatedAt)
            .Select(x => x.ToDto())
            .ToList();
    }

    public static string? Validate(ProductInput input)
    {
        if (string.IsNullOrWhiteSpace(input.Name) || string.IsNullOrWhiteSpace(input.Category))
            return "Product name and category are required.";
        if (input.Name.Trim().Length > 120) return "Product name must be 120 characters or fewer.";
        if (input.Category.Trim().Length > 60) return "Category must be 60 characters or fewer.";
        if ((input.Description ?? "").Length > 2000) return "Description must be 2000 characters or fewer.";
        if (input.Price <= 0) return "Price must be greater than zero.";
        if (input.OriginalPrice < 0) return "MRP cannot be negative.";
        if (input.OriginalPrice > 0 && input.OriginalPrice < input.Price) return "MRP cannot be lower than the selling price.";
        if (input.Stock < 0) return "Stock cannot be negative.";
        return null;
    }

    public async Task<ProductDto> CreateProductAsync(ProductInput input, IReadOnlyList<IFormFile> photos)
    {
        if (photos.Count > ImageStorage.MaxImagesPerProduct)
            throw new StoreException($"You can upload up to {ImageStorage.MaxImagesPerProduct} photos per product.");

        var product = new Product();
        Apply(product, input);

        var saved = new List<string>();
        try
        {
            for (var i = 0; i < photos.Count; i++)
            {
                var fileName = await images.SaveAsync(photos[i]);
                saved.Add(fileName);
                product.Images.Add(new ProductImage { FileName = fileName, SortOrder = i });
            }
            db.Products.Add(product);
            await db.SaveChangesAsync();
        }
        catch
        {
            saved.ForEach(images.Delete);
            throw;
        }
        return product.ToDto();
    }

    public async Task<ProductDto?> UpdateProductAsync(int id, ProductInput input)
    {
        var product = await LoadProductAsync(id);
        if (product is null) return null;
        Apply(product, input);
        await db.SaveChangesAsync();
        return product.ToDto();
    }

    public async Task<ProductDto?> UpdateStockAsync(int id, int quantity)
    {
        var product = await LoadProductAsync(id);
        if (product is null) return null;
        product.Stock = quantity;
        await db.SaveChangesAsync();
        return product.ToDto();
    }

    public async Task<ProductDto?> AddImagesAsync(int id, IReadOnlyList<IFormFile> photos)
    {
        var product = await LoadProductAsync(id);
        if (product is null) return null;
        if (product.Images.Count + photos.Count > ImageStorage.MaxImagesPerProduct)
            throw new StoreException($"A product can have up to {ImageStorage.MaxImagesPerProduct} photos.");

        var next = product.Images.Count == 0 ? 0 : product.Images.Max(x => x.SortOrder) + 1;
        var saved = new List<string>();
        try
        {
            foreach (var photo in photos)
            {
                var fileName = await images.SaveAsync(photo);
                saved.Add(fileName);
                product.Images.Add(new ProductImage { FileName = fileName, SortOrder = next++ });
            }
            await db.SaveChangesAsync();
        }
        catch
        {
            saved.ForEach(images.Delete);
            throw;
        }
        return product.ToDto();
    }

    public async Task<ProductDto?> RemoveImageAsync(int id, int imageId)
    {
        var product = await LoadProductAsync(id);
        var image = product?.Images.FirstOrDefault(x => x.Id == imageId);
        if (product is null || image is null) return null;
        product.Images.Remove(image);
        db.ProductImages.Remove(image);
        await db.SaveChangesAsync();
        images.Delete(image.FileName);
        return product.ToDto();
    }

    /// <summary>Makes the chosen photo the cover (first) photo.</summary>
    public async Task<ProductDto?> SetCoverImageAsync(int id, int imageId)
    {
        var product = await LoadProductAsync(id);
        var cover = product?.Images.FirstOrDefault(x => x.Id == imageId);
        if (product is null || cover is null) return null;
        var ordered = product.Images
            .OrderBy(x => x == cover ? 0 : 1).ThenBy(x => x.SortOrder).ThenBy(x => x.Id)
            .ToList();
        for (var i = 0; i < ordered.Count; i++) ordered[i].SortOrder = i;
        await db.SaveChangesAsync();
        return product.ToDto();
    }

    public async Task<bool> DeleteProductAsync(int id)
    {
        var product = await LoadProductAsync(id);
        if (product is null) return false;
        var files = product.Images.Select(x => x.FileName).ToList();
        db.Products.Remove(product);
        await db.SaveChangesAsync();
        files.ForEach(images.Delete);
        return true;
    }

    private Task<Product?> LoadProductAsync(int id) =>
        db.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id == id);

    private static void Apply(Product product, ProductInput input)
    {
        product.Name = input.Name.Trim();
        product.Description = (input.Description ?? "").Trim();
        product.Category = input.Category.Trim();
        product.Price = input.Price;
        product.OriginalPrice = input.OriginalPrice <= 0 ? input.Price : input.OriginalPrice;
        product.Stock = input.Stock;
        product.IsFeatured = input.IsFeatured;
    }

    // ---------- Orders ----------

    public async Task<OrderDto> CheckoutAsync(CheckoutRequest request)
    {
        var requestedItems = (request.Items ?? [])
            .GroupBy(x => x.ProductId)
            .Select(x => new CheckoutItem(x.Key, x.Sum(y => y.Quantity)))
            .ToList();
        if (requestedItems.Count == 0 || requestedItems.Any(x => x.Quantity <= 0))
            throw new StoreException("Your cart is empty or contains an invalid quantity.");
        if (PhoneNumbers.ToWhatsApp(request.Phone, PhoneCountryCode) is null)
            throw new StoreException("Please enter a valid 10-digit mobile number so we can send your order updates.");

        await WriteGate.WaitAsync();
        try
        {
            var ids = requestedItems.Select(x => x.ProductId).ToList();
            var products = await db.Products.Where(x => ids.Contains(x.Id)).ToListAsync();

            var items = new List<OrderItem>();
            foreach (var requested in requestedItems)
            {
                var product = products.FirstOrDefault(x => x.Id == requested.ProductId)
                    ?? throw new StoreException("A product in your cart is no longer available.");
                if (product.Stock < requested.Quantity)
                    throw new StoreException($"Only {product.Stock} unit(s) of {product.Name} are available.");

                // Stock is held for this order until it is paid or the payment time runs out.
                product.Stock -= requested.Quantity;
                items.Add(new OrderItem
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    UnitPrice = product.Price,
                    Quantity = requested.Quantity
                });
            }

            var subtotal = items.Sum(x => x.UnitPrice * x.Quantity);
            var deliveryFee = subtotal >= FreeDeliveryAbove ? 0 : DeliveryFee;
            var order = new Order
            {
                OrderNumber = $"LF{DateTime.UtcNow:yyMMdd}{Random.Shared.Next(100000, 999999)}",
                CustomerName = request.CustomerName.Trim(),
                Email = request.Email.Trim().ToLowerInvariant(),
                Phone = request.Phone.Trim(),
                Address = request.Address.Trim(),
                Items = items,
                Subtotal = subtotal,
                DeliveryFee = deliveryFee,
                Total = subtotal + deliveryFee,
                Status = OrderState.AwaitingPayment,
                PaymentMethod = PaymentState.MethodUpi,
                PaymentStatus = PaymentState.Pending,
                CreatedAt = DateTime.UtcNow
            };

            db.Orders.Add(order);
            await db.SaveChangesAsync();   // stock deduction and order are saved together
            return order.ToDto(PaymentTimeoutMinutes);
        }
        finally
        {
            WriteGate.Release();
        }
    }

    /// <summary>Customer reports the UPI transaction ID (UTR) after paying.</summary>
    public async Task<OrderDto?> SubmitPaymentAsync(string orderNumber, string email, string reference)
    {
        var normalizedEmail = (email ?? "").Trim().ToLowerInvariant();
        var utr = (reference ?? "").Trim().ToUpperInvariant();

        await WriteGate.WaitAsync();
        try
        {
            var order = await db.Orders.Include(x => x.Items)
                .FirstOrDefaultAsync(x => x.OrderNumber == orderNumber && x.Email == normalizedEmail);
            if (order is null) return null;
            if (order.PaymentMethod != PaymentState.MethodUpi)
                throw new StoreException("This order does not need an online payment.");
            if (order.PaymentStatus == PaymentState.Paid)
                return order.ToDto(PaymentTimeoutMinutes);
            if (order.Status == OrderState.Cancelled)
                throw new StoreException("This order was cancelled because the payment was not completed in time. Please place a new order.");
            if (order.PaymentStatus == PaymentState.Pending && IsExpired(order))
            {
                await CancelAsync(order, PaymentState.Expired);
                await db.SaveChangesAsync();
                throw new StoreException("The payment time for this order has run out, so it was cancelled. Please place a new order.");
            }

            var usedElsewhere = await db.Orders.AnyAsync(x => x.PaymentReference == utr && x.Id != order.Id);
            if (usedElsewhere)
                throw new StoreException("This UPI transaction ID has already been used for another order.");

            order.PaymentReference = utr;
            order.PaymentStatus = PaymentState.Submitted;
            var queued = await QueueNotificationAsync(order, NotificationEvent.OrderPlaced);
            await db.SaveChangesAsync();
            if (queued) notificationSignal.Notify();
            return order.ToDto(PaymentTimeoutMinutes);
        }
        finally
        {
            WriteGate.Release();
        }
    }

    /// <summary>Admin confirms (or rejects) a UPI payment after checking the bank / UPI app.</summary>
    public async Task<OrderDto?> DecidePaymentAsync(int id, bool approve)
    {
        await WriteGate.WaitAsync();
        try
        {
            var order = await db.Orders.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == id);
            if (order is null) return null;
            if (order.PaymentMethod != PaymentState.MethodUpi)
                throw new StoreException("This order was not paid online.");
            if (order.PaymentStatus == PaymentState.Paid)
                throw new StoreException("This payment is already marked as received.");
            if (order.Status == OrderState.Cancelled)
                throw new StoreException("This order is already cancelled.");

            var queued = false;
            if (approve)
            {
                order.PaymentStatus = PaymentState.Paid;
                order.PaidAt = DateTime.UtcNow;
                order.Status = OrderState.Confirmed;
                queued = await QueueNotificationAsync(order, NotificationEvent.PaymentConfirmed);
            }
            else
            {
                await CancelAsync(order, PaymentState.Failed);
            }
            await db.SaveChangesAsync();
            if (queued) notificationSignal.Notify();
            return order.ToDto(PaymentTimeoutMinutes);
        }
        finally
        {
            WriteGate.Release();
        }
    }

    /// <summary>Cancels UPI orders that were not paid in time and returns their items to stock.</summary>
    public async Task<int> CancelExpiredOrdersAsync()
    {
        var cutoff = DateTime.UtcNow.AddMinutes(-PaymentTimeoutMinutes);
        await WriteGate.WaitAsync();
        try
        {
            var expired = await db.Orders.Include(x => x.Items)
                .Where(x => x.PaymentMethod == PaymentState.MethodUpi &&
                            x.PaymentStatus == PaymentState.Pending &&
                            x.Status != OrderState.Cancelled &&
                            x.CreatedAt < cutoff)
                .ToListAsync();
            foreach (var order in expired) await CancelAsync(order, PaymentState.Expired);
            if (expired.Count > 0) await db.SaveChangesAsync();
            return expired.Count;
        }
        finally
        {
            WriteGate.Release();
        }
    }

    public async Task<List<OrderDto>> GetOrdersAsync(string? email = null)
    {
        IQueryable<Order> query = db.Orders.Include(x => x.Items);
        if (!string.IsNullOrWhiteSpace(email))
        {
            var normalized = email.Trim().ToLowerInvariant();
            query = query.Where(x => x.Email == normalized);
        }
        var orders = await query.OrderByDescending(x => x.CreatedAt).ToListAsync();
        return orders.Select(x => x.ToDto(PaymentTimeoutMinutes)).ToList();
    }

    public async Task<OrderDto?> UpdateOrderStatusAsync(int id, string status)
    {
        await WriteGate.WaitAsync();
        try
        {
            var order = await db.Orders.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == id);
            if (order is null) return null;
            if (order.Status == status) return order.ToDto(PaymentTimeoutMinutes);
            if (order.Status == OrderState.Cancelled)
                throw new StoreException("A cancelled order cannot be reopened. Please place a new order.");

            if (status == OrderState.Cancelled)
            {
                await CancelAsync(order, order.PaymentStatus == PaymentState.Paid ? PaymentState.Paid : PaymentState.Failed);
            }
            else
            {
                if (order.PaymentMethod == PaymentState.MethodUpi && order.PaymentStatus != PaymentState.Paid)
                    throw new StoreException("Confirm the UPI payment first (Payment received), then update the delivery status.");
                order.Status = status;
            }
            var queued = status switch
            {
                "Shipped" => await QueueNotificationAsync(order, NotificationEvent.Shipped),
                "Delivered" => await QueueNotificationAsync(order, NotificationEvent.Delivered),
                _ => false
            };
            await db.SaveChangesAsync();
            if (queued) notificationSignal.Notify();
            return order.ToDto(PaymentTimeoutMinutes);
        }
        finally
        {
            WriteGate.Release();
        }
    }

    public async Task<List<OrderDto>> GetAdminOrdersAsync()
    {
        var orders = await db.Orders.Include(x => x.Items).Include(x => x.Notifications)
            .OrderByDescending(x => x.CreatedAt).ToListAsync();
        return orders.Select(x => x.ToAdminDto(PaymentTimeoutMinutes, PhoneCountryCode, StoreName, PublicUrl)).ToList();
    }

    /// <summary>Admin sent the message by hand from WhatsApp.</summary>
    public async Task<bool> MarkNotificationSentManuallyAsync(int id)
    {
        var notification = await db.OrderNotifications.FirstOrDefaultAsync(x => x.Id == id);
        if (notification is null) return false;
        if (notification.Status != NotificationState.Sent)
        {
            notification.Status = NotificationState.ManualSent;
            notification.SentAt = DateTime.UtcNow;
            notification.Detail = null;
            await db.SaveChangesAsync();
        }
        return true;
    }

    /// <summary>Try sending a failed email again (e.g. after fixing the email settings).</summary>
    public async Task<bool> RetryNotificationAsync(int id)
    {
        var notification = await db.OrderNotifications.FirstOrDefaultAsync(x => x.Id == id && x.Channel == NotificationChannel.Email);
        if (notification is null) return false;
        notification.Status = NotificationState.Queued;
        notification.Attempts = 0;
        notification.NextAttemptAt = null;
        notification.Detail = null;
        await db.SaveChangesAsync();
        notificationSignal.Notify();
        return true;
    }

    /// <summary>
    /// Prepares the customer updates for an order event (once per order, event and channel). Caller saves.
    /// Email is queued for automatic sending when email is set up; WhatsApp is always ready for one-tap manual sending.
    /// Returns true when an email was queued.
    /// </summary>
    private async Task<bool> QueueNotificationAsync(Order order, string notificationEvent)
    {
        var existing = await db.OrderNotifications
            .Where(x => x.OrderId == order.Id && (x.Event == notificationEvent || x.Event == NotificationEvent.OwnerAlert))
            .Select(x => new { x.Event, x.Channel })
            .ToListAsync();
        bool Has(string ev, string channel) => existing.Any(x => x.Event == ev && x.Channel == channel);

        if (!Has(notificationEvent, NotificationChannel.WhatsApp))
        {
            var validPhone = PhoneNumbers.ToWhatsApp(order.Phone, PhoneCountryCode) is not null;
            db.OrderNotifications.Add(new OrderNotification
            {
                OrderId = order.Id,
                Channel = NotificationChannel.WhatsApp,
                Event = notificationEvent,
                Status = validPhone ? NotificationState.Manual : NotificationState.Failed,
                Detail = validPhone ? null : $"\"{order.Phone}\" is not a valid mobile number."
            });
        }

        var settings = email.CurrentValue;
        var queuedEmail = false;
        if (settings.IsConfigured && !Has(notificationEvent, NotificationChannel.Email))
        {
            db.OrderNotifications.Add(new OrderNotification { OrderId = order.Id, Channel = NotificationChannel.Email, Event = notificationEvent });
            queuedEmail = true;
        }
        if (notificationEvent == NotificationEvent.OrderPlaced && settings.SendsOwnerAlerts &&
            !Has(NotificationEvent.OwnerAlert, NotificationChannel.Email))
        {
            db.OrderNotifications.Add(new OrderNotification { OrderId = order.Id, Channel = NotificationChannel.Email, Event = NotificationEvent.OwnerAlert });
            queuedEmail = true;
        }
        return queuedEmail;
    }

    private bool IsExpired(Order order) =>
        DateTime.SpecifyKind(order.CreatedAt, DateTimeKind.Utc).AddMinutes(PaymentTimeoutMinutes) < DateTime.UtcNow;

    /// <summary>Marks the order cancelled and puts its items back into stock (caller saves).</summary>
    private async Task CancelAsync(Order order, string paymentStatus)
    {
        var ids = order.Items.Select(x => x.ProductId).ToList();
        var products = await db.Products.Where(x => ids.Contains(x.Id)).ToListAsync();
        foreach (var item in order.Items)
        {
            var product = products.FirstOrDefault(x => x.Id == item.ProductId);
            if (product is not null) product.Stock += item.Quantity;
        }
        order.Status = OrderState.Cancelled;
        order.PaymentStatus = paymentStatus;
    }
}
