using System.Globalization;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using ShopKart.Api;

const long MaxRequestBytes = 90L * 1024 * 1024; // room for 8 photos of up to 10 MB each

var builder = WebApplication.CreateBuilder(args);

// ---------- Storage: one folder holds the SQLite database, uploaded photos and login keys ----------
var dataPath = builder.Configuration["Storage:DataPath"];
if (string.IsNullOrWhiteSpace(dataPath)) dataPath = "App_Data";
if (!Path.IsPathRooted(dataPath)) dataPath = Path.Combine(builder.Environment.ContentRootPath, dataPath);
var uploadsPath = Path.Combine(dataPath, "uploads");
var keysPath = Path.Combine(dataPath, "keys");
Directory.CreateDirectory(uploadsPath);
Directory.CreateDirectory(keysPath);

var connectionString = builder.Configuration.GetConnectionString("Shop");
if (string.IsNullOrWhiteSpace(connectionString))
    connectionString = $"Data Source={Path.Combine(dataPath, "liyazhini.db")}";

builder.Services.AddDbContext<ShopDbContext>(options => options.UseSqlite(connectionString));
builder.Services.AddSingleton(new ImageStorage(uploadsPath));
builder.Services.AddScoped<ShopStore>();
builder.Services.AddHostedService<PaymentExpiryService>();

// Free order notifications: automatic emails (SMTP, e.g. Gmail) + one-tap manual WhatsApp messages
builder.Services.Configure<EmailOptions>(builder.Configuration.GetSection("Email"));
builder.Services.AddSingleton<NotificationSignal>();
builder.Services.AddSingleton<EmailSender>();
builder.Services.AddHostedService<NotificationWorker>();

builder.WebHost.ConfigureKestrel(options => options.Limits.MaxRequestBodySize = MaxRequestBytes);
builder.Services.Configure<FormOptions>(options => options.MultipartBodyLengthLimit = MaxRequestBytes);

// Keeps admins signed in across restarts / container rebuilds.
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(keysPath))
    .SetApplicationName("LiyazhiniFashion");

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // Only the scheme is trusted (so https behind a reverse proxy works); client IPs are not,
    // so the login rate limit cannot be bypassed with a forged X-Forwarded-For header.
    options.ForwardedHeaders = ForwardedHeaders.XForwardedProto;
    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});

// ---------- Admin login ----------
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "lf_admin";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.ExpireTimeSpan = TimeSpan.FromHours(12);
        options.SlidingExpiration = true;
        options.Events.OnRedirectToLogin = context => { context.Response.StatusCode = 401; return Task.CompletedTask; };
        options.Events.OnRedirectToAccessDenied = context => { context.Response.StatusCode = 403; return Task.CompletedTask; };
    });
builder.Services.AddAuthorizationBuilder().AddPolicy("Admin", policy => policy.RequireRole("Admin"));

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("login", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 5, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    options.AddPolicy("public-orders", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
    await SchemaUpgrade.RunAsync(scope.ServiceProvider.GetRequiredService<ShopDbContext>());

var adminUser = app.Configuration["Admin:Username"];
if (string.IsNullOrWhiteSpace(adminUser)) adminUser = "admin";
var adminPassword = app.Configuration["Admin:Password"] ?? "";
if (string.IsNullOrWhiteSpace(adminPassword))
    app.Logger.LogWarning("Admin password is not set. Set the Admin__Password environment variable to use the store admin panel.");
app.Logger.LogInformation("Data folder: {DataPath}", dataPath);

var upiId = (app.Configuration["Payment:UpiId"] ?? "").Trim();
var upiPayeeName = (app.Configuration["Payment:PayeeName"] ?? "").Trim();
if (string.IsNullOrWhiteSpace(upiPayeeName)) upiPayeeName = app.Configuration["Store:Name"] ?? "Liyazhini Fashion";
var emailSettings = app.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<EmailOptions>>().Value;
if (emailSettings.IsConfigured)
    app.Logger.LogInformation("Order emails: on (from {From} via {Host}); owner alerts: {Alerts}.",
        emailSettings.From, emailSettings.SmtpHost, emailSettings.SendsOwnerAlerts ? emailSettings.OwnerAddress : "off");
else
    app.Logger.LogInformation("Order emails: off. WhatsApp updates are sent by hand from Store admin → Orders.");
var upiReady = Regex.IsMatch(upiId, @"^[A-Za-z0-9._-]{2,256}@[A-Za-z][A-Za-z0-9]{1,63}$");
if (!upiReady)
    app.Logger.LogWarning("UPI ID is missing or invalid. Set Payment__UpiId (for example liyazhini@okaxis) so customers can pay and place orders.");

app.UseForwardedHeaders();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(uploadsPath),
    RequestPath = "/uploads",
    OnPrepareResponse = context =>
        context.Context.Response.Headers.CacheControl = "public,max-age=31536000,immutable"
});
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

var api = app.MapGroup("/api");

// ---------- Public ----------

api.MapGet("/store", (IConfiguration config) => Results.Ok(new
{
    name = config["Store:Name"] ?? "Liyazhini Fashion",
    deliveryFee = config.GetValue("Store:DeliveryFee", 49m),
    freeDeliveryAbove = config.GetValue("Store:FreeDeliveryAbove", 499m),
    paymentTimeoutMinutes = Math.Max(5, config.GetValue("Store:PaymentTimeoutMinutes", 30)),
    upiId = upiReady ? upiId : null,
    upiPayeeName
}));

api.MapGet("/products", async (ShopStore store, string? search, string? category) =>
    Results.Ok(await store.GetProductsAsync(search, category)));

api.MapPost("/orders", async (ShopStore store, CheckoutRequest request) =>
{
    if (string.IsNullOrWhiteSpace(request.CustomerName) ||
        string.IsNullOrWhiteSpace(request.Email) ||
        string.IsNullOrWhiteSpace(request.Phone) ||
        string.IsNullOrWhiteSpace(request.Address))
        return Results.BadRequest(new { message = "Please complete all delivery details." });
    if (!upiReady)
        return Results.Json(new { message = "Online payment is not set up yet, so orders can't be placed right now. Please try again later." }, statusCode: 503);
    try
    {
        return Results.Ok(await store.CheckoutAsync(request));
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
});

api.MapGet("/orders", async (ShopStore store, string? email) =>
    string.IsNullOrWhiteSpace(email)
        ? Results.BadRequest(new { message = "Please enter the email used for your order." })
        : Results.Ok(await store.GetOrdersAsync(email)))
    .RequireRateLimiting("public-orders");

api.MapPost("/orders/{orderNumber}/payment", async (ShopStore store, string orderNumber, PaymentSubmission request) =>
{
    var reference = (request.Reference ?? "").Trim();
    if (!Regex.IsMatch(reference, @"^[A-Za-z0-9]{8,35}$"))
        return Results.BadRequest(new { message = "Please enter the UPI transaction ID (the 12-digit UTR / UPI Ref No. shown in your UPI app)." });
    try
    {
        var order = await store.SubmitPaymentAsync(orderNumber, request.Email ?? "", reference);
        return order is null ? Results.NotFound(new { message = "Order not found for this email." }) : Results.Ok(order);
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
}).RequireRateLimiting("public-orders");

// ---------- Admin sign-in ----------

api.MapPost("/admin/login", async (HttpContext context, LoginRequest request) =>
{
    if (string.IsNullOrWhiteSpace(adminPassword))
        return Results.Json(new { message = "Admin password is not configured on the server." }, statusCode: 503);
    if (!SecureEquals(request.Username?.Trim() ?? "", adminUser) || !SecureEquals(request.Password ?? "", adminPassword))
        return Results.Json(new { message = "Incorrect username or password." }, statusCode: 401);

    var identity = new ClaimsIdentity(
        [new Claim(ClaimTypes.Name, adminUser), new Claim(ClaimTypes.Role, "Admin")],
        CookieAuthenticationDefaults.AuthenticationScheme);
    await context.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    return Results.Ok(new { authenticated = true, username = adminUser });
}).RequireRateLimiting("login");

api.MapPost("/admin/logout", async (HttpContext context) =>
{
    await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Ok(new { authenticated = false });
});

api.MapGet("/admin/me", (ClaimsPrincipal user) => Results.Ok(new
{
    authenticated = user.IsInRole("Admin"),
    username = user.Identity?.Name
}));

// ---------- Admin (sign-in required) ----------

var admin = api.MapGroup("/admin").RequireAuthorization("Admin");

admin.MapPost("/products", async (HttpRequest request, ShopStore store) =>
{
    if (!request.HasFormContentType)
        return Results.BadRequest(new { message = "Send the product as multipart/form-data." });
    var form = await request.ReadFormAsync();
    var input = ReadProductInput(form);
    var error = ShopStore.Validate(input) ?? await ImageStorage.ValidateAsync(form.Files);
    if (error is not null) return Results.BadRequest(new { message = error });
    try
    {
        var product = await store.CreateProductAsync(input, form.Files.ToList());
        return Results.Created($"/api/products/{product.Id}", product);
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
});

admin.MapPut("/products/{id:int}", async (ShopStore store, int id, ProductInput input) =>
{
    var error = ShopStore.Validate(input);
    if (error is not null) return Results.BadRequest(new { message = error });
    var product = await store.UpdateProductAsync(id, input);
    return product is null ? Results.NotFound() : Results.Ok(product);
});

admin.MapPut("/products/{id:int}/stock", async (ShopStore store, int id, StockRequest request) =>
{
    if (request.Quantity < 0) return Results.BadRequest(new { message = "Stock cannot be negative." });
    var product = await store.UpdateStockAsync(id, request.Quantity);
    return product is null ? Results.NotFound() : Results.Ok(product);
});

admin.MapDelete("/products/{id:int}", async (ShopStore store, int id) =>
    await store.DeleteProductAsync(id) ? Results.NoContent() : Results.NotFound());

admin.MapPost("/products/{id:int}/images", async (HttpRequest request, ShopStore store, int id) =>
{
    if (!request.HasFormContentType) return Results.BadRequest(new { message = "Please choose at least one photo." });
    var form = await request.ReadFormAsync();
    if (form.Files.Count == 0) return Results.BadRequest(new { message = "Please choose at least one photo." });
    var error = await ImageStorage.ValidateAsync(form.Files);
    if (error is not null) return Results.BadRequest(new { message = error });
    try
    {
        var product = await store.AddImagesAsync(id, form.Files.ToList());
        return product is null ? Results.NotFound() : Results.Ok(product);
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
});

admin.MapDelete("/products/{id:int}/images/{imageId:int}", async (ShopStore store, int id, int imageId) =>
{
    var product = await store.RemoveImageAsync(id, imageId);
    return product is null ? Results.NotFound() : Results.Ok(product);
});

admin.MapPut("/products/{id:int}/images/{imageId:int}/cover", async (ShopStore store, int id, int imageId) =>
{
    var product = await store.SetCoverImageAsync(id, imageId);
    return product is null ? Results.NotFound() : Results.Ok(product);
});

admin.MapGet("/orders", async (ShopStore store) => Results.Ok(await store.GetAdminOrdersAsync()));

admin.MapGet("/notifications/status", (Microsoft.Extensions.Options.IOptionsMonitor<EmailOptions> options) => Results.Ok(new
{
    email = options.CurrentValue.IsConfigured,
    ownerAlerts = options.CurrentValue.SendsOwnerAlerts
}));

admin.MapPut("/notifications/{id:int}/manual-sent", async (ShopStore store, int id) =>
    await store.MarkNotificationSentManuallyAsync(id) ? Results.NoContent() : Results.NotFound());

admin.MapPost("/notifications/{id:int}/retry", async (ShopStore store, int id) =>
    await store.RetryNotificationAsync(id) ? Results.NoContent() : Results.NotFound());

admin.MapPut("/orders/{id:int}/payment", async (ShopStore store, int id, PaymentDecision request) =>
{
    try
    {
        var order = await store.DecidePaymentAsync(id, request.Approve);
        return order is null ? Results.NotFound() : Results.Ok(order);
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
});

admin.MapPut("/orders/{id:int}/status", async (ShopStore store, int id, StatusRequest request) =>
{
    if (!OrderState.AdminStatuses.Contains(request.Status))
        return Results.BadRequest(new { message = "Invalid order status." });
    try
    {
        var order = await store.UpdateOrderStatusAsync(id, request.Status);
        return order is null ? Results.NotFound() : Results.Ok(order);
    }
    catch (StoreException exception)
    {
        return Results.BadRequest(new { message = exception.Message });
    }
});

app.MapFallbackToFile("index.html");
app.Run();

static bool SecureEquals(string supplied, string expected) =>
    CryptographicOperations.FixedTimeEquals(
        SHA256.HashData(Encoding.UTF8.GetBytes(supplied)),
        SHA256.HashData(Encoding.UTF8.GetBytes(expected)));

static ProductInput ReadProductInput(IFormCollection form)
{
    static decimal Money(string? value) =>
        decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var result) ? result : 0;
    var stock = int.TryParse(form["stock"], NumberStyles.Integer, CultureInfo.InvariantCulture, out var s) ? s : -1;
    var featured = form["isFeatured"].ToString();
    return new ProductInput(
        form["name"].ToString(),
        form["description"].ToString(),
        form["category"].ToString(),
        Money(form["price"]),
        Money(form["originalPrice"]),
        stock,
        featured is "true" or "on");
}
